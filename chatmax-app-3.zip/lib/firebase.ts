// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app"
import { getAuth } from "firebase/auth"
import { getDatabase } from "firebase/database"

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyColDTGXX7M9Z7jQ9DY_q5O0DZMVyz6Y04",
  authDomain: "chatmax-7cdfb.firebaseapp.com",
  databaseURL: "https://chatmax-7cdfb-default-rtdb.firebaseio.com",
  projectId: "chatmax-7cdfb",
  storageBucket: "chatmax-7cdfb.firebasestorage.app",
  messagingSenderId: "320272291466",
  appId: "1:320272291466:web:7509311ff87244d5857f73",
  measurementId: "G-BXYGXGGY0V",
}

// Initialize Firebase
const app = initializeApp(firebaseConfig)

// Initialize Firebase Authentication and get a reference to the service
export const auth = getAuth(app)

// Initialize Realtime Database and get a reference to the service
export const database = getDatabase(app)

export default app
