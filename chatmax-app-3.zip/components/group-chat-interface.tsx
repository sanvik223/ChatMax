"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { ArrowLeft, Phone, Video, Info, Send, Paperclip, Smile, MoreVertical, Users, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface GroupMember {
  id: string
  name: string
  email: string
  profileImage: string
  isOnline: boolean
  isAdmin: boolean
  joinedAt: string
}

interface Group {
  id: string
  name: string
  description: string
  createdBy: string
  createdAt: string
  members: GroupMember[]
}

interface GroupMessage {
  id: string
  senderId: string
  senderName: string
  senderAvatar: string
  content: string
  type: "text" | "image" | "video" | "document"
  timestamp: Date
  isEdited?: boolean
  editedAt?: Date
}

interface GroupChatInterfaceProps {
  group: Group
  currentUserId: string
  onBack: () => void
  onGroupInfo: () => void
  onDeleteHistory: () => void
  profileGallery: string[]
}

export default function GroupChatInterface({
  group,
  currentUserId,
  onBack,
  onGroupInfo,
  onDeleteHistory,
  profileGallery,
}: GroupChatInterfaceProps) {
  const [message, setMessage] = useState("")
  const [messages, setMessages] = useState<GroupMessage[]>([
    {
      id: "1",
      senderId: "user1",
      senderName: "মোহাম্মদ করিম",
      senderAvatar: "",
      content: "আসসালামু আলাইকুম সবাই!",
      type: "text",
      timestamp: new Date(Date.now() - 3600000),
    },
    {
      id: "2",
      senderId: "user2",
      senderName: "রাহেলা খাতুন",
      senderAvatar: "",
      content: "ওয়ালাইকুম আসসালাম! কেমন আছেন সবাই?",
      type: "text",
      timestamp: new Date(Date.now() - 1800000),
    },
  ])
  const [editingMessageId, setEditingMessageId] = useState<string | null>(null)
  const [editingContent, setEditingContent] = useState("")

  const messagesEndRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const handleSendMessage = () => {
    if (message.trim()) {
      const newMessage: GroupMessage = {
        id: Date.now().toString(),
        senderId: currentUserId,
        senderName: group.members.find((m) => m.id === currentUserId)?.name || "আপনি",
        senderAvatar: group.members.find((m) => m.id === currentUserId)?.profileImage || "",
        content: message.trim(),
        type: "text",
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, newMessage])
      setMessage("")
    }
  }

  const handleEditMessage = (messageId: string) => {
    const messageToEdit = messages.find((m) => m.id === messageId)
    if (messageToEdit) {
      setEditingMessageId(messageId)
      setEditingContent(messageToEdit.content)
    }
  }

  const handleSaveEdit = () => {
    if (editingMessageId && editingContent.trim()) {
      setMessages((prev) =>
        prev.map((m) =>
          m.id === editingMessageId
            ? { ...m, content: editingContent.trim(), isEdited: true, editedAt: new Date() }
            : m,
        ),
      )
      setEditingMessageId(null)
      setEditingContent("")
    }
  }

  const handleDeleteMessage = (messageId: string, deleteForEveryone = false) => {
    if (deleteForEveryone) {
      setMessages((prev) => prev.filter((m) => m.id !== messageId))
    } else {
      setMessages((prev) =>
        prev.map((m) =>
          m.id === messageId ? { ...m, content: "এই মেসেজটি মুছে ফেলা হয়েছে", type: "text" as const } : m,
        ),
      )
    }
  }

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        const newMessage: GroupMessage = {
          id: Date.now().toString(),
          senderId: currentUserId,
          senderName: group.members.find((m) => m.id === currentUserId)?.name || "আপনি",
          senderAvatar: group.members.find((m) => m.id === currentUserId)?.profileImage || "",
          content: e.target?.result as string,
          type: file.type.startsWith("image/") ? "image" : file.type.startsWith("video/") ? "video" : "document",
          timestamp: new Date(),
        }
        setMessages((prev) => [...prev, newMessage])
      }
      reader.readAsDataURL(file)
    }
  }

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString("bn-BD", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
    })
  }

  const onlineMembers = group.members.filter((m) => m.isOnline)

  return (
    <div className="h-[calc(100vh-80px)] flex flex-col bg-background">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border bg-card">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={onBack}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div
            className="flex items-center gap-3 cursor-pointer hover:bg-muted/50 rounded-lg p-2 -m-2"
            onClick={onGroupInfo}
          >
            <div className="relative">
              <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                <Users className="w-6 h-6 text-primary" />
              </div>
            </div>
            <div>
              <h3 className="font-semibold">{group.name}</h3>
              <p className="text-sm text-muted-foreground">
                {onlineMembers.length} জন অনলাইন, {group.members.length} জন সদস্য
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon">
            <Phone className="w-5 h-5" />
          </Button>
          <Button variant="ghost" size="icon">
            <Video className="w-5 h-5" />
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <MoreVertical className="w-5 h-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={onGroupInfo}>
                <Info className="w-4 h-4 mr-2" />
                গ্রুপ তথ্য
              </DropdownMenuItem>
              <DropdownMenuItem onClick={onDeleteHistory} className="text-red-600">
                <Trash2 className="w-4 h-4 mr-2" />
                চ্যাট হিস্টরি মুছুন
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg) => (
          <div key={msg.id} className="space-y-1">
            {/* Sender info for group messages */}
            {msg.senderId !== currentUserId && (
              <div className="flex items-center gap-2 ml-2">
                <Avatar className="w-6 h-6">
                  <AvatarImage
                    src={msg.senderAvatar || profileGallery[Math.floor(Math.random() * profileGallery.length)]}
                    alt={msg.senderName}
                  />
                  <AvatarFallback className="bg-emerald-500 text-white text-xs">
                    {msg.senderName.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <span className="text-sm font-medium text-primary">{msg.senderName}</span>
              </div>
            )}

            <div className={`flex ${msg.senderId === currentUserId ? "justify-end" : "justify-start"}`}>
              <div
                className={`max-w-[70%] ${
                  msg.senderId === currentUserId ? "bg-primary text-primary-foreground" : "bg-muted"
                } rounded-lg p-3 space-y-1`}
              >
                {editingMessageId === msg.id ? (
                  <div className="space-y-2">
                    <Input
                      value={editingContent}
                      onChange={(e) => setEditingContent(e.target.value)}
                      onKeyPress={(e) => e.key === "Enter" && handleSaveEdit()}
                      className="bg-background"
                    />
                    <div className="flex gap-2">
                      <Button size="sm" onClick={handleSaveEdit}>
                        সংরক্ষণ
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => setEditingMessageId(null)}>
                        বাতিল
                      </Button>
                    </div>
                  </div>
                ) : (
                  <>
                    {msg.type === "text" && <p>{msg.content}</p>}
                    {msg.type === "image" && (
                      <img
                        src={msg.content || "/placeholder.svg"}
                        alt="Shared image"
                        className="max-w-full rounded-lg cursor-pointer"
                      />
                    )}
                    {msg.type === "video" && <video src={msg.content} controls className="max-w-full rounded-lg" />}

                    <div className="flex items-center justify-between text-xs opacity-70">
                      <span>{formatTime(msg.timestamp)}</span>
                      {msg.isEdited && <span>সম্পাদিত</span>}
                    </div>
                  </>
                )}

                {msg.senderId === currentUserId && editingMessageId !== msg.id && (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm" className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100">
                        <MoreVertical className="w-3 h-3" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent>
                      <DropdownMenuItem onClick={() => handleEditMessage(msg.id)}>সম্পাদনা</DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleDeleteMessage(msg.id, false)}>
                        আমার জন্য মুছুন
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleDeleteMessage(msg.id, true)} className="text-red-600">
                        সবার জন্য মুছুন
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                )}
              </div>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-4 border-t border-border bg-card">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={() => fileInputRef.current?.click()}>
            <Paperclip className="w-5 h-5" />
          </Button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*,video/*,.pdf,.doc,.docx"
            onChange={handleFileSelect}
            className="hidden"
          />
          <Input
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="একটি মেসেজ লিখুন..."
            onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
            className="flex-1"
          />
          <Button variant="ghost" size="icon">
            <Smile className="w-5 h-5" />
          </Button>
          <Button onClick={handleSendMessage} disabled={!message.trim()}>
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  )
}
