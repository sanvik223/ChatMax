"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

interface StoryRingProps {
  user: {
    id: string
    name: string
    avatar: string
  }
  hasStory: boolean
  isViewed: boolean
  onClick: () => void
}

export default function StoryRing({ user, hasStory, isViewed, onClick }: StoryRingProps) {
  return (
    <div className="flex flex-col items-center gap-2 cursor-pointer" onClick={onClick}>
      <div
        className={`p-0.5 rounded-full ${
          hasStory
            ? isViewed
              ? "bg-gray-300"
              : "bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-500"
            : "bg-gray-200"
        }`}
      >
        <Avatar className="w-16 h-16 border-2 border-white">
          <AvatarImage src={user.avatar || "/placeholder.svg"} />
          <AvatarFallback className="bg-emerald-500 text-white">{user.name.charAt(0)}</AvatarFallback>
        </Avatar>
      </div>
      <span className="text-xs text-gray-600 text-center max-w-[70px] truncate">{user.name}</span>
    </div>
  )
}
