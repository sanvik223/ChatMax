"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Edit, Camera, UserMinus, Ban, Trash2 } from "lucide-react"
import { ProfileGalleryPopup } from "./profile-gallery-popup"

interface UserProfile {
  name: string
  email: string
  profileImage: string
  gender: string
  birthDate: string
  country: string
  address: string
  isOnline: boolean
}

interface UserProfilePopupProps {
  isOpen: boolean
  onClose: () => void
  user: UserProfile
  onUpdateProfile: (updatedUser: UserProfile) => void
  isOwnProfile: boolean
  profileGallery: string[]
  onBlockUser?: () => void
  onDeleteContact?: () => void
  onDeleteAccount?: () => void
}

export function UserProfilePopup({
  isOpen,
  onClose,
  user,
  onUpdateProfile,
  isOwnProfile,
  profileGallery,
  onBlockUser,
  onDeleteContact,
  onDeleteAccount,
}: UserProfilePopupProps) {
  const [isEditing, setIsEditing] = useState(false)
  const [isGalleryOpen, setIsGalleryOpen] = useState(false)
  const [editedUser, setEditedUser] = useState(user)

  const handleSave = () => {
    onUpdateProfile(editedUser)
    setIsEditing(false)
  }

  const handleCancel = () => {
    setEditedUser(user)
    setIsEditing(false)
  }

  const handleProfileImageSelect = (imageUrl: string) => {
    setEditedUser({ ...editedUser, profileImage: imageUrl })
  }

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center">{isOwnProfile ? "আমার প্রোফাইল" : "ইউজার প্রোফাইল"}</DialogTitle>
          </DialogHeader>

          <div className="space-y-6">
            {/* Profile Picture */}
            <div className="text-center">
              <div className="relative inline-block">
                <Avatar className="w-24 h-24">
                  <AvatarImage src={editedUser.profileImage || "/placeholder.svg"} alt={editedUser.name} />
                  <AvatarFallback>{editedUser.name.charAt(0)}</AvatarFallback>
                </Avatar>
                {isOwnProfile && isEditing && (
                  <Button
                    size="sm"
                    className="absolute -bottom-2 -right-2 rounded-full w-8 h-8 p-0"
                    onClick={() => setIsGalleryOpen(true)}
                  >
                    <Camera className="w-4 h-4" />
                  </Button>
                )}
              </div>
              <div className="mt-2 flex items-center justify-center gap-2">
                <div className={`w-3 h-3 rounded-full ${user.isOnline ? "bg-green-500" : "bg-gray-400"}`} />
                <span className="text-sm text-muted-foreground">{user.isOnline ? "অনলাইন" : "অফলাইন"}</span>
              </div>
            </div>

            {/* Profile Information */}
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>নাম</Label>
                {isEditing ? (
                  <Input
                    value={editedUser.name}
                    onChange={(e) => setEditedUser({ ...editedUser, name: e.target.value })}
                  />
                ) : (
                  <p className="text-sm bg-muted p-2 rounded">{user.name}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label>ইমেইল</Label>
                <p className="text-sm bg-muted p-2 rounded">{user.email}</p>
              </div>

              {isOwnProfile && (
                <>
                  <div className="space-y-2">
                    <Label>লিঙ্গ</Label>
                    {isEditing ? (
                      <Select
                        value={editedUser.gender}
                        onValueChange={(value) => setEditedUser({ ...editedUser, gender: value })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="পুরুষ">পুরুষ</SelectItem>
                          <SelectItem value="মহিলা">মহিলা</SelectItem>
                          <SelectItem value="অন্যান্য">অন্যান্য</SelectItem>
                        </SelectContent>
                      </Select>
                    ) : (
                      <p className="text-sm bg-muted p-2 rounded">{user.gender}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label>জন্ম তারিখ</Label>
                    {isEditing ? (
                      <Input
                        type="date"
                        value={editedUser.birthDate}
                        onChange={(e) => setEditedUser({ ...editedUser, birthDate: e.target.value })}
                      />
                    ) : (
                      <p className="text-sm bg-muted p-2 rounded">{user.birthDate}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label>দেশ</Label>
                    {isEditing ? (
                      <Input
                        value={editedUser.country}
                        onChange={(e) => setEditedUser({ ...editedUser, country: e.target.value })}
                      />
                    ) : (
                      <p className="text-sm bg-muted p-2 rounded">{user.country}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label>ঠিকানা</Label>
                    {isEditing ? (
                      <Input
                        value={editedUser.address}
                        onChange={(e) => setEditedUser({ ...editedUser, address: e.target.value })}
                      />
                    ) : (
                      <p className="text-sm bg-muted p-2 rounded">{user.address}</p>
                    )}
                  </div>
                </>
              )}
            </div>

            {/* Action Buttons */}
            <div className="space-y-3">
              {isOwnProfile ? (
                <div className="flex gap-2">
                  {isEditing ? (
                    <>
                      <Button onClick={handleSave} className="flex-1">
                        সংরক্ষণ
                      </Button>
                      <Button onClick={handleCancel} variant="outline" className="flex-1 bg-transparent">
                        বাতিল
                      </Button>
                    </>
                  ) : (
                    <Button onClick={() => setIsEditing(true)} className="w-full">
                      <Edit className="w-4 h-4 mr-2" />
                      প্রোফাইল এডিট করুন
                    </Button>
                  )}
                </div>
              ) : (
                <div className="space-y-2">
                  <Button onClick={onBlockUser} variant="destructive" className="w-full">
                    <Ban className="w-4 h-4 mr-2" />
                    ব্লক করুন
                  </Button>
                  <Button onClick={onDeleteContact} variant="outline" className="w-full bg-transparent">
                    <UserMinus className="w-4 h-4 mr-2" />
                    কন্টাক্ট মুছুন
                  </Button>
                  {onDeleteAccount && (
                    <Button onClick={onDeleteAccount} variant="destructive" className="w-full">
                      <Trash2 className="w-4 h-4 mr-2" />
                      অ্যাকাউন্ট মুছুন
                    </Button>
                  )}
                </div>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <ProfileGalleryPopup
        isOpen={isGalleryOpen}
        onClose={() => setIsGalleryOpen(false)}
        currentProfileImage={editedUser.profileImage}
        onSelectImage={handleProfileImageSelect}
        profileGallery={profileGallery}
      />
    </>
  )
}
