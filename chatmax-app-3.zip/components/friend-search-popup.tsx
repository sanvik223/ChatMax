"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Search, UserPlus, Check, X } from "lucide-react"

interface User {
  id: string
  name: string
  email: string
  profileImage: string
  isOnline: boolean
  relationshipStatus: "none" | "pending" | "friend" | "blocked"
}

interface FriendSearchPopupProps {
  isOpen: boolean
  onClose: () => void
  onSendRequest: (userId: string) => void
  profileGallery: string[]
}

export function FriendSearchPopup({ isOpen, onClose, onSendRequest, profileGallery }: FriendSearchPopupProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<User[]>([])
  const [isSearching, setIsSearching] = useState(false)

  // Mock users for demonstration
  const mockUsers: User[] = [
    {
      id: "1",
      name: "রহিম আহমেদ",
      email: "rahim.ahmed@gmail.com",
      profileImage: profileGallery[1],
      isOnline: true,
      relationshipStatus: "none",
    },
    {
      id: "2",
      name: "ফাতিমা খান",
      email: "fatima.khan@gmail.com",
      profileImage: profileGallery[2],
      isOnline: false,
      relationshipStatus: "none",
    },
    {
      id: "3",
      name: "করিম উদ্দিন",
      email: "karim.uddin@gmail.com",
      profileImage: profileGallery[3],
      isOnline: true,
      relationshipStatus: "pending",
    },
    {
      id: "4",
      name: "সালমা বেগম",
      email: "salma.begum@gmail.com",
      profileImage: profileGallery[4],
      isOnline: true,
      relationshipStatus: "friend",
    },
  ]

  const handleSearch = () => {
    if (!searchQuery.trim()) return

    setIsSearching(true)
    // Simulate API call
    setTimeout(() => {
      const results = mockUsers.filter(
        (user) =>
          user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          user.email.toLowerCase().includes(searchQuery.toLowerCase()),
      )
      setSearchResults(results)
      setIsSearching(false)
    }, 1000)
  }

  const handleSendRequest = (userId: string) => {
    onSendRequest(userId)
    // Update local state
    setSearchResults((prev) =>
      prev.map((user) => (user.id === userId ? { ...user, relationshipStatus: "pending" as const } : user)),
    )
  }

  const getStatusButton = (user: User) => {
    switch (user.relationshipStatus) {
      case "none":
        return (
          <Button size="sm" onClick={() => handleSendRequest(user.id)} className="flex items-center gap-2">
            <UserPlus className="w-4 h-4" />
            রিকোয়েস্ট পাঠান
          </Button>
        )
      case "pending":
        return (
          <Button size="sm" variant="outline" disabled>
            <Check className="w-4 h-4 mr-2" />
            পাঠানো হয়েছে
          </Button>
        )
      case "friend":
        return (
          <Button size="sm" variant="outline" disabled>
            বন্ধু
          </Button>
        )
      case "blocked":
        return (
          <Button size="sm" variant="destructive" disabled>
            <X className="w-4 h-4 mr-2" />
            ব্লক করা
          </Button>
        )
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>বন্ধু খুঁজুন</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Search Input */}
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="নাম বা Gmail দিয়ে খুঁজুন"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleSearch()}
                className="pl-10"
              />
            </div>
            <Button onClick={handleSearch} disabled={isSearching}>
              {isSearching ? "খুঁজছি..." : "খুঁজুন"}
            </Button>
          </div>

          {/* Search Results */}
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {searchResults.length === 0 && searchQuery && !isSearching && (
              <div className="text-center text-muted-foreground py-8">কোনো ইউজার পাওয়া যায়নি</div>
            )}

            {searchResults.map((user) => (
              <div key={user.id} className="flex items-center gap-3 p-3 border rounded-lg">
                <div className="relative">
                  <Avatar className="w-12 h-12">
                    <AvatarImage src={user.profileImage || "/placeholder.svg"} alt={user.name} />
                    <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div
                    className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-background ${
                      user.isOnline ? "bg-green-500" : "bg-gray-400"
                    }`}
                  />
                </div>

                <div className="flex-1 min-w-0">
                  <h4 className="font-medium truncate">{user.name}</h4>
                  <p className="text-sm text-muted-foreground truncate">{user.email}</p>
                </div>

                {getStatusButton(user)}
              </div>
            ))}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
