"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Check, X, Ban } from "lucide-react"

interface FriendRequest {
  id: string
  name: string
  email: string
  profileImage: string
  isOnline: boolean
  requestDate: string
}

interface FriendRequestItemProps {
  request: FriendRequest
  onAccept: (requestId: string) => void
  onReject: (requestId: string) => void
  onBlock: (requestId: string) => void
}

export function FriendRequestItem({ request, onAccept, onReject, onBlock }: FriendRequestItemProps) {
  return (
    <div className="flex items-center gap-3 p-3 border rounded-lg">
      <div className="relative">
        <Avatar className="w-12 h-12">
          <AvatarImage src={request.profileImage || "/placeholder.svg"} alt={request.name} />
          <AvatarFallback>{request.name.charAt(0)}</AvatarFallback>
        </Avatar>
        <div
          className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-background ${
            request.isOnline ? "bg-green-500" : "bg-gray-400"
          }`}
        />
      </div>

      <div className="flex-1 min-w-0">
        <h4 className="font-medium truncate">{request.name}</h4>
        <p className="text-sm text-muted-foreground truncate">{request.email}</p>
        <p className="text-xs text-muted-foreground">{request.requestDate}</p>
      </div>

      <div className="flex gap-2">
        <Button size="sm" onClick={() => onAccept(request.id)} className="flex items-center gap-1">
          <Check className="w-4 h-4" />
          গ্রহণ
        </Button>
        <Button size="sm" variant="outline" onClick={() => onReject(request.id)}>
          <X className="w-4 h-4" />
          প্রত্যাখ্যান
        </Button>
        <Button size="sm" variant="destructive" onClick={() => onBlock(request.id)}>
          <Ban className="w-4 h-4" />
          ব্লক
        </Button>
      </div>
    </div>
  )
}
