"use client"

import { useState } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { MoreVertical, Edit, Trash2, Check, X, Download } from "lucide-react"
import { format } from "date-fns"

interface Message {
  id: string
  senderId: string
  senderName: string
  senderImage: string
  content: string
  type: "text" | "image" | "video" | "document"
  mediaUrl?: string
  fileName?: string
  timestamp: Date
  isEdited: boolean
  editedAt?: Date
  isOwnMessage: boolean
}

interface MessageItemProps {
  message: Message
  onEdit: (messageId: string, newContent: string) => void
  onDelete: (messageId: string, deleteForEveryone: boolean) => void
  onMediaView: (mediaUrl: string, type: string) => void
}

export function MessageItem({ message, onEdit, onDelete, onMediaView }: MessageItemProps) {
  const [isEditing, setIsEditing] = useState(false)
  const [editContent, setEditContent] = useState(message.content)

  const handleSaveEdit = () => {
    if (editContent.trim() !== message.content) {
      onEdit(message.id, editContent.trim())
    }
    setIsEditing(false)
  }

  const handleCancelEdit = () => {
    setEditContent(message.content)
    setIsEditing(false)
  }

  const handleDelete = (deleteForEveryone: boolean) => {
    onDelete(message.id, deleteForEveryone)
  }

  const renderMessageContent = () => {
    if (message.type === "text") {
      return isEditing ? (
        <div className="space-y-2">
          <Input
            value={editContent}
            onChange={(e) => setEditContent(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && handleSaveEdit()}
            className="text-sm"
          />
          <div className="flex gap-2">
            <Button size="sm" onClick={handleSaveEdit}>
              <Check className="w-3 h-3" />
            </Button>
            <Button size="sm" variant="outline" onClick={handleCancelEdit}>
              <X className="w-3 h-3" />
            </Button>
          </div>
        </div>
      ) : (
        <p className="text-sm">{message.content}</p>
      )
    }

    if (message.type === "image") {
      return (
        <div className="space-y-2">
          <button
            onClick={() => onMediaView(message.mediaUrl!, "image")}
            className="block max-w-xs rounded-lg overflow-hidden hover:opacity-90 transition-opacity"
          >
            <img src={message.mediaUrl || "/placeholder.svg"} alt="Shared image" className="w-full h-auto" />
          </button>
          {message.content && <p className="text-sm">{message.content}</p>}
        </div>
      )
    }

    if (message.type === "video") {
      return (
        <div className="space-y-2">
          <div className="max-w-xs">
            <video src={message.mediaUrl} controls className="w-full rounded-lg" />
          </div>
          {message.content && <p className="text-sm">{message.content}</p>}
        </div>
      )
    }

    if (message.type === "document") {
      return (
        <div className="space-y-2">
          <div className="flex items-center gap-2 p-3 bg-muted rounded-lg max-w-xs">
            <div className="flex-1">
              <p className="text-sm font-medium">{message.fileName}</p>
              <p className="text-xs text-muted-foreground">ডকুমেন্ট</p>
            </div>
            <Button size="sm" variant="ghost" onClick={() => window.open(message.mediaUrl, "_blank")}>
              <Download className="w-4 h-4" />
            </Button>
          </div>
          {message.content && <p className="text-sm">{message.content}</p>}
        </div>
      )
    }
  }

  return (
    <div className={`flex gap-3 p-3 ${message.isOwnMessage ? "flex-row-reverse" : "flex-row"}`}>
      {!message.isOwnMessage && (
        <Avatar className="w-8 h-8 flex-shrink-0">
          <AvatarImage src={message.senderImage || "/placeholder.svg"} alt={message.senderName} />
          <AvatarFallback>{message.senderName.charAt(0)}</AvatarFallback>
        </Avatar>
      )}

      <div className={`flex-1 max-w-xs ${message.isOwnMessage ? "text-right" : "text-left"}`}>
        {!message.isOwnMessage && (
          <p className="text-xs font-medium text-muted-foreground mb-1">{message.senderName}</p>
        )}

        <div
          className={`inline-block p-3 rounded-lg ${
            message.isOwnMessage ? "bg-primary text-primary-foreground" : "bg-muted"
          }`}
        >
          {renderMessageContent()}

          <div className="flex items-center justify-between mt-2 gap-2">
            <span className="text-xs opacity-70">
              {format(message.timestamp, "HH:mm")}
              {message.isEdited && <span className="ml-1">(সম্পাদিত)</span>}
            </span>

            {message.isOwnMessage && !isEditing && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button size="sm" variant="ghost" className="h-6 w-6 p-0 opacity-70 hover:opacity-100">
                    <MoreVertical className="w-3 h-3" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  {message.type === "text" && (
                    <DropdownMenuItem onClick={() => setIsEditing(true)}>
                      <Edit className="w-4 h-4 mr-2" />
                      সম্পাদনা
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuItem onClick={() => handleDelete(false)}>
                    <Trash2 className="w-4 h-4 mr-2" />
                    আমার জন্য মুছুন
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleDelete(true)} className="text-destructive">
                    <Trash2 className="w-4 h-4 mr-2" />
                    সবার জন্য মুছুন
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
