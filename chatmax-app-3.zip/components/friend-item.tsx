"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { MessageCircle, Phone, Video, MoreVertical } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface Friend {
  id: string
  name: string
  email: string
  profileImage: string
  isOnline: boolean
  lastSeen?: string
}

interface FriendItemProps {
  friend: Friend
  onStartChat: (friendId: string) => void
  onAudioCall: (friendId: string) => void
  onVideoCall: (friendId: string) => void
  onViewProfile: (friendId: string) => void
  onRemoveFriend: (friendId: string) => void
  onBlockFriend: (friendId: string) => void
}

export function FriendItem({
  friend,
  onStartChat,
  onAudioCall,
  onVideoCall,
  onViewProfile,
  onRemoveFriend,
  onBlockFriend,
}: FriendItemProps) {
  return (
    <div className="flex items-center gap-3 p-3 border rounded-lg hover:bg-muted/50 transition-colors">
      <button onClick={() => onViewProfile(friend.id)} className="relative">
        <Avatar className="w-12 h-12">
          <AvatarImage src={friend.profileImage || "/placeholder.svg"} alt={friend.name} />
          <AvatarFallback>{friend.name.charAt(0)}</AvatarFallback>
        </Avatar>
        <div
          className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-background ${
            friend.isOnline ? "bg-green-500" : "bg-gray-400"
          }`}
        />
      </button>

      <div className="flex-1 min-w-0">
        <h4 className="font-medium truncate">{friend.name}</h4>
        <p className="text-sm text-muted-foreground truncate">
          {friend.isOnline ? "অনলাইন" : friend.lastSeen || "অফলাইন"}
        </p>
      </div>

      <div className="flex items-center gap-2">
        <Button size="sm" variant="ghost" onClick={() => onStartChat(friend.id)}>
          <MessageCircle className="w-4 h-4" />
        </Button>
        <Button size="sm" variant="ghost" onClick={() => onAudioCall(friend.id)}>
          <Phone className="w-4 h-4" />
        </Button>
        <Button size="sm" variant="ghost" onClick={() => onVideoCall(friend.id)}>
          <Video className="w-4 h-4" />
        </Button>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button size="sm" variant="ghost">
              <MoreVertical className="w-4 h-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => onViewProfile(friend.id)}>প্রোফাইল দেখুন</DropdownMenuItem>
            <DropdownMenuItem onClick={() => onRemoveFriend(friend.id)}>বন্ধু তালিকা থেকে সরান</DropdownMenuItem>
            <DropdownMenuItem onClick={() => onBlockFriend(friend.id)} className="text-destructive">
              ব্লক করুন
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  )
}
