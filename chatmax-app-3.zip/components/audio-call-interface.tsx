"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { PhoneOff, Volume2, VolumeX, Mic, MicOff } from "lucide-react"

interface Friend {
  id: string
  name: string
  email: string
  profileImage: string
  isOnline: boolean
}

interface AudioCallInterfaceProps {
  friend: Friend
  onEndCall: () => void
  callDuration: number
}

export function AudioCallInterface({ friend, onEndCall, callDuration }: AudioCallInterfaceProps) {
  const [isMuted, setIsMuted] = useState(false)
  const [isSpeakerOn, setIsSpeakerOn] = useState(false)
  const [callStatus, setCallStatus] = useState<"connecting" | "connected" | "ringing">("connecting")

  useEffect(() => {
    // Simulate call connection
    const timer = setTimeout(() => {
      setCallStatus("ringing")
      setTimeout(() => {
        setCallStatus("connected")
      }, 3000)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const getCallStatusText = () => {
    switch (callStatus) {
      case "connecting":
        return "সংযোগ করা হচ্ছে..."
      case "ringing":
        return "রিং করছে..."
      case "connected":
        return formatDuration(callDuration)
      default:
        return ""
    }
  }

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-primary/20 to-primary/5 flex flex-col items-center justify-center z-50">
      <div className="text-center space-y-8">
        {/* Profile Section */}
        <div className="space-y-4">
          <Avatar className="w-32 h-32 mx-auto ring-4 ring-primary/20">
            <AvatarImage src={friend.profileImage || "/placeholder.svg"} alt={friend.name} />
            <AvatarFallback className="text-2xl">{friend.name.charAt(0)}</AvatarFallback>
          </Avatar>

          <div>
            <h2 className="text-2xl font-bold text-foreground">{friend.name}</h2>
            <p className="text-lg text-muted-foreground">{getCallStatusText()}</p>
          </div>
        </div>

        {/* Call Status Indicator */}
        <div className="flex justify-center">
          {callStatus === "connecting" && (
            <div className="flex space-x-1">
              <div className="w-2 h-2 bg-primary rounded-full animate-bounce"></div>
              <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "0.1s" }}></div>
              <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "0.2s" }}></div>
            </div>
          )}
          {callStatus === "ringing" && <div className="w-4 h-4 bg-primary rounded-full animate-pulse"></div>}
          {callStatus === "connected" && <div className="w-4 h-4 bg-green-500 rounded-full"></div>}
        </div>

        {/* Call Controls */}
        <div className="flex items-center justify-center space-x-6">
          {/* Mute Button */}
          <Button
            variant={isMuted ? "destructive" : "secondary"}
            size="lg"
            className="w-16 h-16 rounded-full"
            onClick={() => setIsMuted(!isMuted)}
          >
            {isMuted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
          </Button>

          {/* End Call Button */}
          <Button
            variant="destructive"
            size="lg"
            className="w-20 h-20 rounded-full bg-red-500 hover:bg-red-600"
            onClick={onEndCall}
          >
            <PhoneOff className="w-8 h-8" />
          </Button>

          {/* Speaker Button */}
          <Button
            variant={isSpeakerOn ? "default" : "secondary"}
            size="lg"
            className="w-16 h-16 rounded-full"
            onClick={() => setIsSpeakerOn(!isSpeakerOn)}
          >
            {isSpeakerOn ? <Volume2 className="w-6 h-6" /> : <VolumeX className="w-6 h-6" />}
          </Button>
        </div>

        {/* Control Labels */}
        <div className="flex items-center justify-center space-x-6 text-sm text-muted-foreground">
          <span>{isMuted ? "মিউট" : "আনমিউট"}</span>
          <span>কল শেষ</span>
          <span>{isSpeakerOn ? "স্পিকার অন" : "স্পিকার অফ"}</span>
        </div>
      </div>
    </div>
  )
}
