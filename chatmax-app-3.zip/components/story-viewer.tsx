"use client"

import { useState, useEffect } from "react"
import { X, Heart, MessageCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

interface Story {
  id: string
  userId: string
  userName: string
  userAvatar: string
  type: "image" | "video" | "text"
  content: string
  backgroundColor?: string
  timestamp: number
  expiresAt: number
  views: string[]
}

interface StoryViewerProps {
  stories: Story[]
  currentStoryIndex: number
  onClose: () => void
  onNext: () => void
  onPrevious: () => void
  currentUser: string
}

export default function StoryViewer({
  stories,
  currentStoryIndex,
  onClose,
  onNext,
  onPrevious,
  currentUser,
}: StoryViewerProps) {
  const [progress, setProgress] = useState(0)
  const [isPlaying, setIsPlaying] = useState(true)

  const currentStory = stories[currentStoryIndex]
  const storyDuration = 5000 // 5 seconds per story

  useEffect(() => {
    if (!isPlaying) return

    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          onNext()
          return 0
        }
        return prev + 100 / (storyDuration / 100)
      })
    }, 100)

    return () => clearInterval(interval)
  }, [isPlaying, onNext])

  useEffect(() => {
    setProgress(0)
  }, [currentStoryIndex])

  const handlePause = () => setIsPlaying(false)
  const handleResume = () => setIsPlaying(true)

  const formatTimeAgo = (timestamp: number) => {
    const now = Date.now()
    const diff = now - timestamp
    const hours = Math.floor(diff / (1000 * 60 * 60))
    if (hours < 1) return "এখনই"
    if (hours < 24) return `${hours} ঘন্টা আগে`
    return `${Math.floor(hours / 24)} দিন আগে`
  }

  return (
    <div className="fixed inset-0 bg-black z-50 flex items-center justify-center">
      {/* Story Progress Bar */}
      <div className="absolute top-4 left-4 right-4 flex gap-1 z-10">
        {stories.map((_, index) => (
          <div key={index} className="flex-1 h-1 bg-white/30 rounded-full overflow-hidden">
            <div
              className="h-full bg-white transition-all duration-100"
              style={{
                width: index < currentStoryIndex ? "100%" : index === currentStoryIndex ? `${progress}%` : "0%",
              }}
            />
          </div>
        ))}
      </div>

      {/* Story Header */}
      <div className="absolute top-8 left-4 right-4 flex items-center justify-between z-10">
        <div className="flex items-center gap-3">
          <Avatar className="w-10 h-10 border-2 border-white">
            <AvatarImage src={currentStory.userAvatar || "/placeholder.svg"} />
            <AvatarFallback className="bg-emerald-500 text-white">{currentStory.userName.charAt(0)}</AvatarFallback>
          </Avatar>
          <div>
            <p className="text-white font-medium">{currentStory.userName}</p>
            <p className="text-white/70 text-sm">{formatTimeAgo(currentStory.timestamp)}</p>
          </div>
        </div>
        <Button variant="ghost" size="icon" onClick={onClose} className="text-white hover:bg-white/20">
          <X className="w-6 h-6" />
        </Button>
      </div>

      {/* Story Content */}
      <div
        className="w-full h-full flex items-center justify-center relative"
        onMouseDown={handlePause}
        onMouseUp={handleResume}
        onTouchStart={handlePause}
        onTouchEnd={handleResume}
      >
        {currentStory.type === "image" && (
          <img
            src={currentStory.content || "/placeholder.svg"}
            alt="Story"
            className="max-w-full max-h-full object-contain"
          />
        )}

        {currentStory.type === "video" && (
          <video src={currentStory.content} className="max-w-full max-h-full object-contain" autoPlay muted loop />
        )}

        {currentStory.type === "text" && (
          <div
            className="w-full h-full flex items-center justify-center p-8"
            style={{ backgroundColor: currentStory.backgroundColor || "#1f2937" }}
          >
            <p className="text-white text-2xl text-center font-medium leading-relaxed">{currentStory.content}</p>
          </div>
        )}

        {/* Navigation Areas */}
        <div className="absolute left-0 top-0 w-1/3 h-full cursor-pointer" onClick={onPrevious} />
        <div className="absolute right-0 top-0 w-1/3 h-full cursor-pointer" onClick={onNext} />
      </div>

      {/* Story Actions */}
      <div className="absolute bottom-8 left-4 right-4 flex items-center gap-4 z-10">
        <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
          <Heart className="w-6 h-6" />
        </Button>
        <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
          <MessageCircle className="w-6 h-6" />
        </Button>
        <div className="flex-1" />
        <p className="text-white/70 text-sm">{currentStory.views.length} জন দেখেছে</p>
      </div>
    </div>
  )
}
