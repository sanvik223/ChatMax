"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { MessageItem } from "./message-item"
import {
  Send,
  Paperclip,
  ImageIcon,
  Video,
  FileText,
  Phone,
  VideoIcon,
  MoreVertical,
  ArrowLeft,
  Trash2,
  Eye,
} from "lucide-react"
import { MessageCircle } from "lucide-react" // Declared MessageCircle here

interface Message {
  id: string
  senderId: string
  senderName: string
  senderImage: string
  content: string
  type: "text" | "image" | "video" | "document"
  mediaUrl?: string
  fileName?: string
  timestamp: Date
  isEdited: boolean
  editedAt?: Date
  isOwnMessage: boolean
}

interface Friend {
  id: string
  name: string
  email: string
  profileImage: string
  isOnline: boolean
  lastSeen?: string
}

interface ChatInterfaceProps {
  friend: Friend
  currentUser: any
  onBack: () => void
  onAudioCall: () => void
  onVideoCall: () => void
  onViewProfile: () => void
  onDeleteHistory: () => void
  onBlockUser: () => void
}

export function ChatInterface({
  friend,
  currentUser,
  onBack,
  onAudioCall,
  onVideoCall,
  onViewProfile,
  onDeleteHistory,
  onBlockUser,
}: ChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      senderId: friend.id,
      senderName: friend.name,
      senderImage: friend.profileImage,
      content: "আসসালামু আলাইকুম! কেমন আছেন?",
      type: "text",
      timestamp: new Date(Date.now() - 3600000),
      isEdited: false,
      isOwnMessage: false,
    },
    {
      id: "2",
      senderId: currentUser.email,
      senderName: currentUser.name,
      senderImage: currentUser.profileImage,
      content: "ওয়ালাইকুম আসসালাম! আলহামদুলিল্লাহ ভালো আছি। আপনি কেমন?",
      type: "text",
      timestamp: new Date(Date.now() - 3500000),
      isEdited: false,
      isOwnMessage: true,
    },
    {
      id: "3",
      senderId: friend.id,
      senderName: friend.name,
      senderImage: friend.profileImage,
      content: "আমিও ভালো আছি। আজ কী করছেন?",
      type: "text",
      timestamp: new Date(Date.now() - 3000000),
      isEdited: false,
      isOwnMessage: false,
    },
  ])

  const [newMessage, setNewMessage] = useState("")
  const [isMediaViewOpen, setIsMediaViewOpen] = useState(false)
  const [viewingMedia, setViewingMedia] = useState<{ url: string; type: string } | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSendMessage = () => {
    if (!newMessage.trim()) return

    const message: Message = {
      id: Date.now().toString(),
      senderId: currentUser.email,
      senderName: currentUser.name,
      senderImage: currentUser.profileImage,
      content: newMessage.trim(),
      type: "text",
      timestamp: new Date(),
      isEdited: false,
      isOwnMessage: true,
    }

    setMessages((prev) => [...prev, message])
    setNewMessage("")
  }

  const handleEditMessage = (messageId: string, newContent: string) => {
    setMessages((prev) =>
      prev.map((msg) =>
        msg.id === messageId ? { ...msg, content: newContent, isEdited: true, editedAt: new Date() } : msg,
      ),
    )
  }

  const handleDeleteMessage = (messageId: string, deleteForEveryone: boolean) => {
    if (deleteForEveryone) {
      setMessages((prev) => prev.filter((msg) => msg.id !== messageId))
    } else {
      // In a real app, this would hide the message only for the current user
      setMessages((prev) => prev.filter((msg) => msg.id !== messageId))
    }
  }

  const handleMediaView = (mediaUrl: string, type: string) => {
    setViewingMedia({ url: mediaUrl, type })
    setIsMediaViewOpen(true)
  }

  const handleFileUpload = (type: "image" | "video" | "document") => {
    // Simulate file upload
    const message: Message = {
      id: Date.now().toString(),
      senderId: currentUser.email,
      senderName: currentUser.name,
      senderImage: currentUser.profileImage,
      content: type === "image" ? "ছবি পাঠানো হয়েছে" : type === "video" ? "ভিডিও পাঠানো হয়েছে" : "ডকুমেন্ট পাঠানো হয়েছে",
      type: type,
      mediaUrl:
        type === "image"
          ? "/placeholder.svg?height=200&width=300"
          : type === "video"
            ? "/placeholder-video.mp4"
            : "/placeholder-document.pdf",
      fileName: type === "document" ? "document.pdf" : undefined,
      timestamp: new Date(),
      isEdited: false,
      isOwnMessage: true,
    }

    setMessages((prev) => [...prev, message])
  }

  const handleClearHistory = () => {
    if (confirm("সমস্ত চ্যাট হিস্টরি মুছে ফেলতে চান?")) {
      setMessages([])
      onDeleteHistory()
    }
  }

  return (
    <div className="flex flex-col h-full">
      {/* Chat Header */}
      <div className="flex items-center gap-3 p-4 border-b border-border bg-card">
        <Button variant="ghost" size="icon" onClick={onBack}>
          <ArrowLeft className="w-5 h-5" />
        </Button>

        <button onClick={onViewProfile} className="flex items-center gap-3 flex-1">
          <div className="relative">
            <Avatar className="w-10 h-10">
              <AvatarImage src={friend.profileImage || "/placeholder.svg"} alt={friend.name} />
              <AvatarFallback>{friend.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div
              className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-background ${
                friend.isOnline ? "bg-green-500" : "bg-gray-400"
              }`}
            />
          </div>

          <div className="text-left">
            <h3 className="font-semibold">{friend.name}</h3>
            <p className="text-sm text-muted-foreground">{friend.isOnline ? "অনলাইন" : friend.lastSeen || "অফলাইন"}</p>
          </div>
        </button>

        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={onAudioCall}>
            <Phone className="w-5 h-5" />
          </Button>
          <Button variant="ghost" size="icon" onClick={onVideoCall}>
            <VideoIcon className="w-5 h-5" />
          </Button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <MoreVertical className="w-5 h-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={onViewProfile}>
                <Eye className="w-4 h-4 mr-2" />
                প্রোফাইল দেখুন
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleClearHistory}>
                <Trash2 className="w-4 h-4 mr-2" />
                চ্যাট হিস্টরি মুছুন
              </DropdownMenuItem>
              <DropdownMenuItem onClick={onBlockUser} className="text-destructive">
                ব্লক করুন
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <div className="text-center text-muted-foreground py-8">
            <MessageCircle className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>কোনো মেসেজ নেই। প্রথম মেসেজ পাঠান!</p>
          </div>
        ) : (
          messages.map((message) => (
            <MessageItem
              key={message.id}
              message={message}
              onEdit={handleEditMessage}
              onDelete={handleDeleteMessage}
              onMediaView={handleMediaView}
            />
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Message Input */}
      <div className="p-4 border-t border-border bg-card">
        <div className="flex items-center gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <Paperclip className="w-5 h-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start">
              <DropdownMenuItem onClick={() => handleFileUpload("image")}>
                <ImageIcon className="w-4 h-4 mr-2" />
                ছবি
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleFileUpload("video")}>
                <Video className="w-4 h-4 mr-2" />
                ভিডিও
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleFileUpload("document")}>
                <FileText className="w-4 h-4 mr-2" />
                ডকুমেন্ট
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <Input
            placeholder="একটি মেসেজ লিখুন..."
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
            className="flex-1"
          />

          <Button onClick={handleSendMessage} disabled={!newMessage.trim()}>
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Media Viewer Dialog */}
      <Dialog open={isMediaViewOpen} onOpenChange={setIsMediaViewOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>মিডিয়া দেখুন</DialogTitle>
          </DialogHeader>
          {viewingMedia && (
            <div className="flex justify-center">
              {viewingMedia.type === "image" ? (
                <img
                  src={viewingMedia.url || "/placeholder.svg"}
                  alt="Viewing media"
                  className="max-w-full max-h-96 object-contain"
                />
              ) : (
                <video src={viewingMedia.url} controls className="max-w-full max-h-96" />
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      <input ref={fileInputRef} type="file" className="hidden" accept="image/*,video/*,.pdf,.doc,.docx" />
    </div>
  )
}
