"use client"

import { useState } from "react"
import { X, Users, Crown, UserPlus, UserMinus, Trash2, Edit } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface GroupMember {
  id: string
  name: string
  email: string
  profileImage: string
  isOnline: boolean
  isAdmin: boolean
  joinedAt: string
}

interface Group {
  id: string
  name: string
  description: string
  createdBy: string
  createdAt: string
  members: GroupMember[]
}

interface Friend {
  id: string
  name: string
  email: string
  profileImage: string
  isOnline: boolean
}

interface GroupInfoPopupProps {
  isOpen: boolean
  onClose: () => void
  group: Group
  currentUserId: string
  friends: Friend[]
  onAddMembers: (groupId: string, memberIds: string[]) => void
  onRemoveMember: (groupId: string, memberId: string) => void
  onLeaveGroup: (groupId: string) => void
  onDeleteGroup: (groupId: string) => void
  onUpdateGroup: (groupId: string, updates: { name?: string; description?: string }) => void
  profileGallery: string[]
}

export default function GroupInfoPopup({
  isOpen,
  onClose,
  group,
  currentUserId,
  friends,
  onAddMembers,
  onRemoveMember,
  onLeaveGroup,
  onDeleteGroup,
  onUpdateGroup,
  profileGallery,
}: GroupInfoPopupProps) {
  const [isEditing, setIsEditing] = useState(false)
  const [editName, setEditName] = useState(group.name)
  const [editDescription, setEditDescription] = useState(group.description)
  const [selectedFriends, setSelectedFriends] = useState<string[]>([])

  if (!isOpen) return null

  const isCurrentUserAdmin = group.members.find((m) => m.id === currentUserId)?.isAdmin || false
  const availableFriends = friends.filter((f) => !group.members.some((m) => m.id === f.id))

  const handleSaveEdit = () => {
    if (editName.trim() !== group.name || editDescription.trim() !== group.description) {
      onUpdateGroup(group.id, {
        name: editName.trim(),
        description: editDescription.trim(),
      })
    }
    setIsEditing(false)
  }

  const handleAddSelectedMembers = () => {
    if (selectedFriends.length > 0) {
      onAddMembers(group.id, selectedFriends)
      setSelectedFriends([])
    }
  }

  const toggleFriendSelection = (friendId: string) => {
    setSelectedFriends((prev) => (prev.includes(friendId) ? prev.filter((id) => id !== friendId) : [...prev, friendId]))
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-card rounded-lg w-full max-w-lg max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          <div className="flex items-center gap-3">
            <Users className="w-6 h-6 text-primary" />
            <h2 className="text-lg font-semibold">গ্রুপ তথ্য</h2>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* Content */}
        <div className="max-h-[calc(90vh-120px)] overflow-y-auto">
          <Tabs defaultValue="info" className="w-full">
            <TabsList className="grid w-full grid-cols-3 m-4">
              <TabsTrigger value="info">তথ্য</TabsTrigger>
              <TabsTrigger value="members">সদস্য ({group.members.length})</TabsTrigger>
              <TabsTrigger value="add">যোগ করুন</TabsTrigger>
            </TabsList>

            <TabsContent value="info" className="p-4 space-y-4">
              {/* Group Info */}
              <div className="text-center space-y-4">
                <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                  <Users className="w-10 h-10 text-primary" />
                </div>

                {isEditing ? (
                  <div className="space-y-3">
                    <Input
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      placeholder="গ্রুপের নাম"
                      maxLength={50}
                    />
                    <Input
                      value={editDescription}
                      onChange={(e) => setEditDescription(e.target.value)}
                      placeholder="গ্রুপের বিবরণ"
                      maxLength={100}
                    />
                    <div className="flex gap-2">
                      <Button size="sm" onClick={handleSaveEdit}>
                        সংরক্ষণ
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => setIsEditing(false)}>
                        বাতিল
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <div className="flex items-center justify-center gap-2">
                      <h3 className="text-xl font-semibold">{group.name}</h3>
                      {isCurrentUserAdmin && (
                        <Button size="icon" variant="ghost" onClick={() => setIsEditing(true)}>
                          <Edit className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                    {group.description && <p className="text-muted-foreground">{group.description}</p>}
                    <p className="text-sm text-muted-foreground">
                      তৈরি: {new Date(group.createdAt).toLocaleDateString("bn-BD")}
                    </p>
                  </div>
                )}
              </div>

              {/* Actions */}
              <div className="space-y-2">
                <Button
                  variant="outline"
                  className="w-full justify-start text-orange-600 hover:text-orange-700 bg-transparent"
                  onClick={() => onLeaveGroup(group.id)}
                >
                  <UserMinus className="w-4 h-4 mr-2" />
                  গ্রুপ ছেড়ে দিন
                </Button>

                {isCurrentUserAdmin && (
                  <Button
                    variant="outline"
                    className="w-full justify-start text-red-600 hover:text-red-700 bg-transparent"
                    onClick={() => {
                      if (confirm("আপনি কি নিশ্চিত যে এই গ্রুপটি মুছে ফেলতে চান?")) {
                        onDeleteGroup(group.id)
                      }
                    }}
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    গ্রুপ মুছে ফেলুন
                  </Button>
                )}
              </div>
            </TabsContent>

            <TabsContent value="members" className="p-4 space-y-2">
              <div className="space-y-2">
                {group.members.map((member) => (
                  <div key={member.id} className="flex items-center gap-3 p-2 rounded-lg">
                    <Avatar className="w-10 h-10">
                      <AvatarImage
                        src={member.profileImage || profileGallery[Math.floor(Math.random() * profileGallery.length)]}
                        alt={member.name}
                      />
                      <AvatarFallback className="bg-emerald-500 text-white">{member.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <p className="font-medium">{member.name}</p>
                        {member.isAdmin && <Crown className="w-4 h-4 text-yellow-500" />}
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {member.id === currentUserId ? "আপনি" : member.email}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className={`w-3 h-3 rounded-full ${member.isOnline ? "bg-green-500" : "bg-gray-400"}`} />
                      {isCurrentUserAdmin && member.id !== currentUserId && (
                        <Button
                          size="icon"
                          variant="ghost"
                          className="text-red-600 hover:text-red-700"
                          onClick={() => {
                            if (confirm(`${member.name} কে গ্রুপ থেকে সরাতে চান?`)) {
                              onRemoveMember(group.id, member.id)
                            }
                          }}
                        >
                          <UserMinus className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="add" className="p-4 space-y-4">
              {availableFriends.length === 0 ? (
                <div className="text-center text-muted-foreground py-8">সব বন্ধু ইতিমধ্যে গ্রুপে আছে</div>
              ) : (
                <>
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">বন্ধু যোগ করুন</h4>
                    {selectedFriends.length > 0 && (
                      <Button size="sm" onClick={handleAddSelectedMembers}>
                        <UserPlus className="w-4 h-4 mr-2" />
                        যোগ করুন ({selectedFriends.length})
                      </Button>
                    )}
                  </div>

                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {availableFriends.map((friend) => (
                      <div
                        key={friend.id}
                        className={`flex items-center gap-3 p-2 rounded-lg cursor-pointer transition-colors ${
                          selectedFriends.includes(friend.id)
                            ? "bg-primary/10 border border-primary/20"
                            : "hover:bg-muted/50"
                        }`}
                        onClick={() => toggleFriendSelection(friend.id)}
                      >
                        <Avatar className="w-10 h-10">
                          <AvatarImage
                            src={
                              friend.profileImage || profileGallery[Math.floor(Math.random() * profileGallery.length)]
                            }
                            alt={friend.name}
                          />
                          <AvatarFallback className="bg-emerald-500 text-white">{friend.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <p className="font-medium">{friend.name}</p>
                          <p className="text-sm text-muted-foreground">{friend.email}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className={`w-3 h-3 rounded-full ${friend.isOnline ? "bg-green-500" : "bg-gray-400"}`} />
                          {selectedFriends.includes(friend.id) && (
                            <div className="w-5 h-5 bg-primary rounded-full flex items-center justify-center">
                              <X className="w-3 h-3 text-white" />
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
