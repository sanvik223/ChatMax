"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Upload, Check } from "lucide-react"

interface ProfileGalleryPopupProps {
  isOpen: boolean
  onClose: () => void
  currentProfileImage: string
  onSelectImage: (imageUrl: string) => void
  profileGallery: string[]
}

export function ProfileGalleryPopup({
  isOpen,
  onClose,
  currentProfileImage,
  onSelectImage,
  profileGallery,
}: ProfileGalleryPopupProps) {
  const [selectedImage, setSelectedImage] = useState(currentProfileImage)

  const handleSave = () => {
    onSelectImage(selectedImage)
    onClose()
  }

  const handleUpload = () => {
    // Simulate file upload
    alert("ফাইল আপলোড ফিচার শীঘ্রই আসছে")
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-center">প্রোফাইল গ্যালারি</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Current Selection */}
          <div className="text-center">
            <div className="mb-4">
              <Avatar className="w-24 h-24 mx-auto">
                <AvatarImage src={selectedImage || "/placeholder.svg"} alt="Selected profile" />
                <AvatarFallback>প্রোফাইল</AvatarFallback>
              </Avatar>
            </div>
            <p className="text-sm text-muted-foreground">বর্তমান নির্বাচন</p>
          </div>

          {/* Upload Options */}
          <div className="flex gap-2 justify-center">
            <Button onClick={handleUpload} variant="outline" size="sm">
              <Upload className="w-4 h-4 mr-2" />
              নতুন ছবি আপলোড
            </Button>
          </div>

          {/* Gallery Grid */}
          <div className="grid grid-cols-4 gap-4">
            {profileGallery.map((image, index) => (
              <button
                key={index}
                className={`relative aspect-square rounded-lg overflow-hidden border-2 transition-all hover:scale-105 ${
                  selectedImage === image
                    ? "border-primary ring-2 ring-primary/20"
                    : "border-border hover:border-primary/50"
                }`}
                onClick={() => setSelectedImage(image)}
              >
                <img
                  src={image || "/placeholder.svg"}
                  alt={`Profile option ${index + 1}`}
                  className="w-full h-full object-cover"
                />
                {selectedImage === image && (
                  <div className="absolute inset-0 bg-primary/20 flex items-center justify-center">
                    <Check className="w-6 h-6 text-primary" />
                  </div>
                )}
              </button>
            ))}
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 justify-end">
            <Button variant="outline" onClick={onClose}>
              বাতিল
            </Button>
            <Button onClick={handleSave}>সংরক্ষণ করুন</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
