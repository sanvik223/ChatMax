"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { format } from "date-fns"

interface ChatListItem {
  id: string
  friendId: string
  friendName: string
  friendImage: string
  isOnline: boolean
  lastMessage: string
  lastMessageTime: Date
  unreadCount: number
  lastMessageType: "text" | "image" | "video" | "document"
}

interface ChatListItemProps {
  chat: ChatListItem
  onClick: () => void
  isActive: boolean
}

export function ChatListItem({ chat, onClick, isActive }: ChatListItemProps) {
  const getLastMessagePreview = () => {
    switch (chat.lastMessageType) {
      case "image":
        return "📷 ছবি"
      case "video":
        return "🎥 ভিডিও"
      case "document":
        return "📄 ডকুমেন্ট"
      default:
        return chat.lastMessage
    }
  }

  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-3 p-3 rounded-lg transition-colors text-left ${
        isActive ? "bg-primary/10 border border-primary/20" : "hover:bg-muted/50"
      }`}
    >
      <div className="relative">
        <Avatar className="w-12 h-12">
          <AvatarImage src={chat.friendImage || "/placeholder.svg"} alt={chat.friendName} />
          <AvatarFallback>{chat.friendName.charAt(0)}</AvatarFallback>
        </Avatar>
        <div
          className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-background ${
            chat.isOnline ? "bg-green-500" : "bg-gray-400"
          }`}
        />
      </div>

      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between mb-1">
          <h4 className="font-medium truncate">{chat.friendName}</h4>
          <span className="text-xs text-muted-foreground">{format(chat.lastMessageTime, "HH:mm")}</span>
        </div>
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground truncate">{getLastMessagePreview()}</p>
          {chat.unreadCount > 0 && (
            <span className="bg-primary text-primary-foreground text-xs rounded-full px-2 py-0.5 min-w-[20px] text-center">
              {chat.unreadCount}
            </span>
          )}
        </div>
      </div>
    </button>
  )
}
