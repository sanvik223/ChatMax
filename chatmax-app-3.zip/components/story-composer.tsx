"use client"

import type React from "react"

import { useState, useRef } from "react"
import { X, Camera, Type, Palette, Send } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"

interface StoryComposerProps {
  onClose: () => void
  onPublish: (story: {
    type: "image" | "video" | "text"
    content: string
    backgroundColor?: string
  }) => void
}

const backgroundColors = [
  "#1f2937",
  "#dc2626",
  "#ea580c",
  "#ca8a04",
  "#16a34a",
  "#0891b2",
  "#2563eb",
  "#7c3aed",
  "#c026d3",
  "#e11d48",
]

export default function StoryComposer({ onClose, onPublish }: StoryComposerProps) {
  const [storyType, setStoryType] = useState<"image" | "video" | "text">("text")
  const [textContent, setTextContent] = useState("")
  const [selectedColor, setSelectedColor] = useState(backgroundColors[0])
  const [mediaFile, setMediaFile] = useState<File | null>(null)
  const [mediaPreview, setMediaPreview] = useState<string>("")
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      setMediaFile(file)
      const reader = new FileReader()
      reader.onload = (e) => {
        setMediaPreview(e.target?.result as string)
      }
      reader.readAsDataURL(file)

      if (file.type.startsWith("image/")) {
        setStoryType("image")
      } else if (file.type.startsWith("video/")) {
        setStoryType("video")
      }
    }
  }

  const handlePublish = () => {
    if (storyType === "text" && textContent.trim()) {
      onPublish({
        type: "text",
        content: textContent.trim(),
        backgroundColor: selectedColor,
      })
    } else if ((storyType === "image" || storyType === "video") && mediaPreview) {
      onPublish({
        type: storyType,
        content: mediaPreview,
      })
    }
  }

  return (
    <div className="fixed inset-0 bg-black z-50 flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-800">
        <Button variant="ghost" size="icon" onClick={onClose} className="text-white hover:bg-gray-800">
          <X className="w-6 h-6" />
        </Button>
        <h2 className="text-white font-semibold">নতুন স্টোরি</h2>
        <Button
          onClick={handlePublish}
          disabled={!textContent.trim() && !mediaPreview}
          className="bg-emerald-500 hover:bg-emerald-600 text-white"
        >
          <Send className="w-4 h-4 mr-2" />
          পাবলিশ
        </Button>
      </div>

      {/* Story Type Selector */}
      <div className="flex items-center gap-4 p-4 border-b border-gray-800">
        <Button
          variant={storyType === "text" ? "default" : "ghost"}
          size="sm"
          onClick={() => setStoryType("text")}
          className="text-white"
        >
          <Type className="w-4 h-4 mr-2" />
          টেক্সট
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => fileInputRef.current?.click()}
          className="text-white hover:bg-gray-800"
        >
          <Camera className="w-4 h-4 mr-2" />
          ছবি/ভিডিও
        </Button>
        <input ref={fileInputRef} type="file" accept="image/*,video/*" onChange={handleFileSelect} className="hidden" />
      </div>

      {/* Story Preview */}
      <div className="flex-1 flex items-center justify-center p-4">
        {storyType === "text" && (
          <div
            className="w-full max-w-sm aspect-[9/16] rounded-lg flex items-center justify-center p-6"
            style={{ backgroundColor: selectedColor }}
          >
            <Textarea
              value={textContent}
              onChange={(e) => setTextContent(e.target.value)}
              placeholder="আপনার স্টোরি লিখুন..."
              className="bg-transparent border-none text-white text-xl text-center resize-none placeholder:text-white/70 focus:ring-0"
              rows={6}
            />
          </div>
        )}

        {(storyType === "image" || storyType === "video") && mediaPreview && (
          <div className="w-full max-w-sm aspect-[9/16] rounded-lg overflow-hidden">
            {storyType === "image" ? (
              <img
                src={mediaPreview || "/placeholder.svg"}
                alt="Story preview"
                className="w-full h-full object-cover"
              />
            ) : (
              <video src={mediaPreview} className="w-full h-full object-cover" controls />
            )}
          </div>
        )}
      </div>

      {/* Color Picker for Text Stories */}
      {storyType === "text" && (
        <div className="p-4 border-t border-gray-800">
          <div className="flex items-center gap-2 mb-3">
            <Palette className="w-5 h-5 text-white" />
            <span className="text-white text-sm">ব্যাকগ্রাউন্ড রং</span>
          </div>
          <div className="flex gap-3 overflow-x-auto">
            {backgroundColors.map((color) => (
              <button
                key={color}
                onClick={() => setSelectedColor(color)}
                className={`w-10 h-10 rounded-full border-2 flex-shrink-0 ${
                  selectedColor === color ? "border-white" : "border-transparent"
                }`}
                style={{ backgroundColor: color }}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
