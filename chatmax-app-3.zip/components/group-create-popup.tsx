"use client"

import { useState } from "react"
import { X, Users, Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Checkbox } from "@/components/ui/checkbox"

interface Friend {
  id: string
  name: string
  email: string
  profileImage: string
  isOnline: boolean
}

interface GroupCreatePopupProps {
  isOpen: boolean
  onClose: () => void
  friends: Friend[]
  onCreateGroup: (groupData: {
    name: string
    description: string
    members: string[]
  }) => void
  profileGallery: string[]
}

export default function GroupCreatePopup({
  isOpen,
  onClose,
  friends,
  onCreateGroup,
  profileGallery,
}: GroupCreatePopupProps) {
  const [groupName, setGroupName] = useState("")
  const [groupDescription, setGroupDescription] = useState("")
  const [selectedMembers, setSelectedMembers] = useState<string[]>([])

  if (!isOpen) return null

  const handleMemberToggle = (friendId: string) => {
    setSelectedMembers((prev) => (prev.includes(friendId) ? prev.filter((id) => id !== friendId) : [...prev, friendId]))
  }

  const handleCreateGroup = () => {
    if (groupName.trim() && selectedMembers.length > 0) {
      onCreateGroup({
        name: groupName.trim(),
        description: groupDescription.trim(),
        members: selectedMembers,
      })
      setGroupName("")
      setGroupDescription("")
      setSelectedMembers([])
      onClose()
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-card rounded-lg w-full max-w-md max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          <div className="flex items-center gap-3">
            <Users className="w-6 h-6 text-primary" />
            <h2 className="text-lg font-semibold">নতুন গ্রুপ তৈরি</h2>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4 max-h-[calc(90vh-120px)] overflow-y-auto">
          {/* Group Info */}
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="groupName">গ্রুপের নাম *</Label>
              <Input
                id="groupName"
                value={groupName}
                onChange={(e) => setGroupName(e.target.value)}
                placeholder="গ্রুপের নাম লিখুন"
                maxLength={50}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="groupDescription">বিবরণ (ঐচ্ছিক)</Label>
              <Input
                id="groupDescription"
                value={groupDescription}
                onChange={(e) => setGroupDescription(e.target.value)}
                placeholder="গ্রুপের বিবরণ লিখুন"
                maxLength={100}
              />
            </div>
          </div>

          {/* Member Selection */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label>সদস্য নির্বাচন করুন ({selectedMembers.length})</Label>
              <span className="text-sm text-muted-foreground">{friends.length} জন বন্ধু</span>
            </div>

            <div className="space-y-2 max-h-64 overflow-y-auto">
              {friends.length === 0 ? (
                <div className="text-center text-muted-foreground py-4">কোনো বন্ধু নেই</div>
              ) : (
                friends.map((friend) => (
                  <div
                    key={friend.id}
                    className="flex items-center space-x-3 p-2 rounded-lg hover:bg-muted/50 cursor-pointer"
                    onClick={() => handleMemberToggle(friend.id)}
                  >
                    <Checkbox
                      checked={selectedMembers.includes(friend.id)}
                      onChange={() => handleMemberToggle(friend.id)}
                    />
                    <Avatar className="w-10 h-10">
                      <AvatarImage
                        src={friend.profileImage || profileGallery[Math.floor(Math.random() * profileGallery.length)]}
                        alt={friend.name}
                      />
                      <AvatarFallback className="bg-emerald-500 text-white">{friend.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <p className="font-medium">{friend.name}</p>
                      <p className="text-sm text-muted-foreground">{friend.email}</p>
                    </div>
                    <div className={`w-3 h-3 rounded-full ${friend.isOnline ? "bg-green-500" : "bg-gray-400"}`} />
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-border">
          <div className="flex gap-3">
            <Button variant="outline" onClick={onClose} className="flex-1 bg-transparent">
              বাতিল
            </Button>
            <Button
              onClick={handleCreateGroup}
              disabled={!groupName.trim() || selectedMembers.length === 0}
              className="flex-1"
            >
              <Plus className="w-4 h-4 mr-2" />
              গ্রুপ তৈরি
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
