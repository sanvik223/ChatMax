"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Video, VideoOff, Mic, MicOff, PhoneOff } from "lucide-react"

interface Friend {
  id: string
  name: string
  email: string
  profileImage: string
  isOnline: boolean
}

interface VideoCallInterfaceProps {
  friend: Friend
  onEndCall: () => void
  callDuration: number
}

export function VideoCallInterface({ friend, onEndCall, callDuration }: VideoCallInterfaceProps) {
  const [isMuted, setIsMuted] = useState(false)
  const [isCameraOn, setIsCameraOn] = useState(true)
  const [callStatus, setCallStatus] = useState<"connecting" | "connected" | "ringing">("connecting")
  const localVideoRef = useRef<HTMLVideoElement>(null)
  const remoteVideoRef = useRef<HTMLVideoElement>(null)

  useEffect(() => {
    // Simulate call connection
    const timer = setTimeout(() => {
      setCallStatus("ringing")
      setTimeout(() => {
        setCallStatus("connected")
      }, 3000)
    }, 1000)

    // Simulate getting user media
    if (isCameraOn) {
      navigator.mediaDevices
        ?.getUserMedia({ video: true, audio: true })
        .then((stream) => {
          if (localVideoRef.current) {
            localVideoRef.current.srcObject = stream
          }
        })
        .catch((err) => console.log("Camera access denied:", err))
    }

    return () => clearTimeout(timer)
  }, [isCameraOn])

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const getCallStatusText = () => {
    switch (callStatus) {
      case "connecting":
        return "সংযোগ করা হচ্ছে..."
      case "ringing":
        return "রিং করছে..."
      case "connected":
        return formatDuration(callDuration)
      default:
        return ""
    }
  }

  const toggleCamera = () => {
    setIsCameraOn(!isCameraOn)
    if (localVideoRef.current?.srcObject) {
      const stream = localVideoRef.current.srcObject as MediaStream
      const videoTrack = stream.getVideoTracks()[0]
      if (videoTrack) {
        videoTrack.enabled = !isCameraOn
      }
    }
  }

  const toggleMute = () => {
    setIsMuted(!isMuted)
    if (localVideoRef.current?.srcObject) {
      const stream = localVideoRef.current.srcObject as MediaStream
      const audioTrack = stream.getAudioTracks()[0]
      if (audioTrack) {
        audioTrack.enabled = isMuted
      }
    }
  }

  return (
    <div className="fixed inset-0 bg-black flex flex-col z-50">
      {/* Video Area */}
      <div className="flex-1 relative">
        {/* Remote Video (Friend) */}
        <div className="w-full h-full bg-gray-900 flex items-center justify-center">
          {callStatus === "connected" ? (
            <video ref={remoteVideoRef} className="w-full h-full object-cover" autoPlay playsInline />
          ) : (
            <div className="text-center space-y-4">
              <Avatar className="w-32 h-32 mx-auto ring-4 ring-white/20">
                <AvatarImage src={friend.profileImage || "/placeholder.svg"} alt={friend.name} />
                <AvatarFallback className="text-2xl text-white">{friend.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <div>
                <h2 className="text-2xl font-bold text-white">{friend.name}</h2>
                <p className="text-lg text-gray-300">{getCallStatusText()}</p>
              </div>
              {callStatus === "connecting" && (
                <div className="flex justify-center space-x-1">
                  <div className="w-2 h-2 bg-white rounded-full animate-bounce"></div>
                  <div
                    className="w-2 h-2 bg-white rounded-full animate-bounce"
                    style={{ animationDelay: "0.1s" }}
                  ></div>
                  <div
                    className="w-2 h-2 bg-white rounded-full animate-bounce"
                    style={{ animationDelay: "0.2s" }}
                  ></div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Local Video (Self) - Picture in Picture */}
        <div className="absolute top-4 right-4 w-32 h-24 bg-gray-800 rounded-lg overflow-hidden border-2 border-white/20">
          {isCameraOn ? (
            <video ref={localVideoRef} className="w-full h-full object-cover scale-x-[-1]" autoPlay playsInline muted />
          ) : (
            <div className="w-full h-full bg-gray-700 flex items-center justify-center">
              <VideoOff className="w-8 h-8 text-gray-400" />
            </div>
          )}
        </div>

        {/* Call Duration */}
        {callStatus === "connected" && (
          <div className="absolute top-4 left-4 bg-black/50 text-white px-3 py-1 rounded-full text-sm">
            {formatDuration(callDuration)}
          </div>
        )}
      </div>

      {/* Call Controls */}
      <div className="bg-black/80 p-6">
        <div className="flex items-center justify-center space-x-6">
          {/* Mute Button */}
          <Button
            variant={isMuted ? "destructive" : "secondary"}
            size="lg"
            className="w-16 h-16 rounded-full bg-gray-700 hover:bg-gray-600"
            onClick={toggleMute}
          >
            {isMuted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
          </Button>

          {/* End Call Button */}
          <Button
            variant="destructive"
            size="lg"
            className="w-20 h-20 rounded-full bg-red-500 hover:bg-red-600"
            onClick={onEndCall}
          >
            <PhoneOff className="w-8 h-8" />
          </Button>

          {/* Camera Button */}
          <Button
            variant={isCameraOn ? "secondary" : "destructive"}
            size="lg"
            className="w-16 h-16 rounded-full bg-gray-700 hover:bg-gray-600"
            onClick={toggleCamera}
          >
            {isCameraOn ? <Video className="w-6 h-6" /> : <VideoOff className="w-6 h-6" />}
          </Button>
        </div>

        {/* Control Labels */}
        <div className="flex items-center justify-center space-x-6 text-sm text-gray-300 mt-4">
          <span>{isMuted ? "মিউট" : "আনমিউট"}</span>
          <span>কল শেষ</span>
          <span>{isCameraOn ? "ক্যামেরা অন" : "ক্যামেরা অফ"}</span>
        </div>
      </div>
    </div>
  )
}
