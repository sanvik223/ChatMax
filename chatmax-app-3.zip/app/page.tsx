"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Label } from "@/components/ui/label"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { MessageCircle, Search, Plus, Settings, Bell, User, Users, ArrowLeft } from "lucide-react"
import { UserProfilePopup } from "@/components/user-profile-popup"
import { FriendSearchPopup } from "@/components/friend-search-popup"
import { FriendRequestItem } from "@/components/friend-request-item"
import { FriendItem } from "@/components/friend-item"
import { ChatInterface } from "@/components/chat-interface"
import { AudioCallInterface } from "@/components/audio-call-interface"
import { VideoCallInterface } from "@/components/video-call-interface"
import StoryViewer from "@/components/story-viewer"
import StoryComposer from "@/components/story-composer"
import StoryRing from "@/components/story-ring"
import GroupCreatePopup from "@/components/group-create-popup"
import GroupInfoPopup from "@/components/group-info-popup"
import GroupChatInterface from "@/components/group-chat-interface"

const useMediaQuery = (query: string) => {
  const [matches, setMatches] = useState(false)

  useEffect(() => {
    const media = window.matchMedia(query)
    if (media.matches !== matches) {
      setMatches(media.matches)
    }
    const listener = () => setMatches(media.matches)
    media.addListener(listener)
    return () => media.removeListener(listener)
  }, [matches, query])

  return matches
}

interface UserProfile {
  name: string
  email: string
  profileImage: string
  gender: string
  birthDate: string
  country: string
  address: string
  isOnline: boolean
}

interface FriendRequest {
  id: string
  name: string
  email: string
  profileImage: string
  isOnline: boolean
  requestDate: string
}

interface Friend {
  id: string
  name: string
  email: string
  profileImage: string
  isOnline: boolean
  lastSeen?: string
}

interface ChatItem {
  id: string
  friendId: string
  friendName: string
  friendImage: string
  isOnline: boolean
  lastMessage: string
  lastMessageTime: Date
  unreadCount: number
  lastMessageType: "text" | "image" | "video" | "document"
}

interface Story {
  id: string
  userId: string
  userName: string
  userAvatar: string
  type: "image" | "video" | "text"
  content: string
  backgroundColor?: string
  timestamp: number
  expiresAt: number
  views: string[]
}

interface GroupMember {
  id: string
  name: string
  email: string
  profileImage: string
  isOnline: boolean
  isAdmin: boolean
  joinedAt: string
}

interface Group {
  id: string
  name: string
  description: string
  createdBy: string
  createdAt: string
  members: GroupMember[]
}

export default function ChatMaxApp() {
  const isMobile = useMediaQuery("(max-width: 768px)")
  const [showSidebar, setShowSidebar] = useState(true)

  const [currentView, setCurrentView] = useState("auth")
  const [authMode, setAuthMode] = useState("login")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [name, setName] = useState("")
  const [isEmailVerified, setIsEmailVerified] = useState(false)

  const [currentUser, setCurrentUser] = useState<UserProfile>({
    name: "",
    email: "",
    profileImage: "",
    gender: "",
    birthDate: "",
    country: "",
    address: "",
    isOnline: true,
  })

  const [isProfilePopupOpen, setIsProfilePopupOpen] = useState(false)
  const [isFriendSearchOpen, setIsFriendSearchOpen] = useState(false)
  const [selectedProfileImage, setSelectedProfileImage] = useState("")
  const [activeChatId, setActiveChatId] = useState<string | null>(null)
  const [selectedFriend, setSelectedFriend] = useState<Friend | null>(null)

  const [isInAudioCall, setIsInAudioCall] = useState(false)
  const [isInVideoCall, setIsInVideoCall] = useState(false)
  const [callFriend, setCallFriend] = useState<Friend | null>(null)
  const [callDuration, setCallDuration] = useState(0)

  const [stories, setStories] = useState<Story[]>([
    {
      id: "1",
      userId: "1",
      userName: "মোহাম্মদ করিম",
      userAvatar: "",
      type: "text",
      content: "আজ খুব সুন্দর একটি দিন! 🌞",
      backgroundColor: "#2563eb",
      timestamp: Date.now() - 3600000,
      expiresAt: Date.now() + 20 * 3600000,
      views: ["current-user"],
    },
    {
      id: "2",
      userId: "2",
      userName: "রাহেলা খাতুন",
      userAvatar: "",
      type: "image",
      content: "",
      timestamp: Date.now() - 7200000,
      expiresAt: Date.now() + 17 * 3600000,
      views: [],
    },
  ])
  const [isStoryViewerOpen, setIsStoryViewerOpen] = useState(false)
  const [isStoryComposerOpen, setIsStoryComposerOpen] = useState(false)
  const [currentStoryIndex, setCurrentStoryIndex] = useState(0)

  const [friendRequests, setFriendRequests] = useState<FriendRequest[]>([
    {
      id: "1",
      name: "আহমেদ হাসান",
      email: "ahmed.hasan@gmail.com",
      profileImage: "",
      isOnline: true,
      requestDate: "২ ঘন্টা আগে",
    },
    {
      id: "2",
      name: "নাদিয়া রহমান",
      email: "nadia.rahman@gmail.com",
      profileImage: "",
      isOnline: false,
      requestDate: "১ দিন আগে",
    },
  ])

  const [friends, setFriends] = useState<Friend[]>([
    {
      id: "1",
      name: "মোহাম্মদ করিম",
      email: "mohammad.karim@gmail.com",
      profileImage: "",
      isOnline: true,
    },
    {
      id: "2",
      name: "রাহেলা খাতুন",
      email: "rahela.khatun@gmail.com",
      profileImage: "",
      isOnline: false,
      lastSeen: "৫ মিনিট আগে",
    },
  ])

  const [chatList, setChatList] = useState<ChatItem[]>([
    {
      id: "1",
      friendId: "1",
      friendName: "মোহাম্মদ করিম",
      friendImage: "",
      isOnline: true,
      lastMessage: "আসসালামু আলাইকুম! কেমন আছেন?",
      lastMessageTime: new Date(Date.now() - 3600000),
      unreadCount: 2,
      lastMessageType: "text",
    },
    {
      id: "2",
      friendId: "2",
      friendName: "রাহেলা খাতুন",
      friendImage: "",
      isOnline: false,
      lastMessage: "ধন্যবাদ!",
      lastMessageTime: new Date(Date.now() - 7200000),
      unreadCount: 0,
      lastMessageType: "text",
    },
  ])

  const [groups, setGroups] = useState<Group[]>([])
  const [selectedGroup, setSelectedGroup] = useState<Group | null>(null)
  const [isGroupCreateOpen, setIsGroupCreateOpen] = useState(false)
  const [isGroupInfoOpen, setIsGroupInfoOpen] = useState(false)
  const [activeGroupChatId, setActiveGroupChatId] = useState<string | null>(null)

  const profileGallery = [
    "https://i.postimg.cc/XqmH2vYg/253f9da5-9e7d-47b3-b08d-6bd069240dd4.jpg",
    "https://i.postimg.cc/xjXSPJsM/2ffb6fe5-3d77-42fe-a2e8-beeaeb39a323.jpg",
    "https://i.postimg.cc/Rh6GnzLJ/9948eec7-e635-49ea-a446-69e3a0de2db7.jpg",
    "https://i.postimg.cc/L8dQLh79/look-At-Me.jpg",
    "https://i.postimg.cc/ZqjhwrtF/penup-1720324478752192.png",
    "https://i.postimg.cc/g0W5FrqS/Rain.jpg",
    "https://i.postimg.cc/fWrrW8f0/Tag-a-friend-who-d-use-one-of-these-All-profile-pictures-are-free-file-Pictu.jpg",
    "https://i.postimg.cc/fTXyBgHc/file-000000000d6861fd95a626cb08f776be.png",
    "https://i.postimg.cc/zfDfDDq7/file-0000000017446230b74f917a1d7f7d7e.png",
    "https://i.postimg.cc/dVY1XmXz/file-00000000381861f8a2a4715aed89e8cc.png",
    "https://i.postimg.cc/QM6dFLt3/penup-1606655248700042.jpg",
    "https://i.postimg.cc/nhGzt9fM/penup-1616848692523492.png",
  ]

  useEffect(() => {
    let interval: NodeJS.Timeout
    if (isInAudioCall || isInVideoCall) {
      interval = setInterval(() => {
        setCallDuration((prev) => prev + 1)
      }, 1000)
    }
    return () => {
      if (interval) clearInterval(interval)
    }
  }, [isInAudioCall, isInVideoCall])

  const handleMobileBack = () => {
    if (selectedGroup || selectedFriend) {
      handleBackToList()
    } else {
      setShowSidebar(true)
    }
  }

  const handleMobileChatSelect = (chatId: string) => {
    handleChatSelect(chatId)
    if (isMobile) {
      setShowSidebar(false)
    }
  }

  const handleMobileGroupSelect = (groupId: string) => {
    handleGroupSelect(groupId)
    if (isMobile) {
      setShowSidebar(false)
    }
  }

  const handleMobileStartChat = (friendId: string) => {
    handleStartChat(friendId)
    if (isMobile) {
      setShowSidebar(false)
    }
  }

  const handleSendFriendRequest = (userId: string) => {
    alert("বন্ধুত্বের অনুরোধ পাঠানো হয়েছে!")
  }

  const handleAcceptRequest = (requestId: string) => {
    const request = friendRequests.find((r) => r.id === requestId)
    if (request) {
      setFriends((prev) => [
        ...prev,
        {
          id: request.id,
          name: request.name,
          email: request.email,
          profileImage: request.profileImage,
          isOnline: request.isOnline,
        },
      ])
      setFriendRequests((prev) => prev.filter((r) => r.id !== requestId))
      alert(`${request.name} এর সাথে বন্ধুত্ব হয়েছে!`)
    }
  }

  const handleRejectRequest = (requestId: string) => {
    setFriendRequests((prev) => prev.filter((r) => r.id !== requestId))
    alert("অনুরোধ প্রত্যাখ্যান করা হয়েছে")
  }

  const handleBlockRequest = (requestId: string) => {
    setFriendRequests((prev) => prev.filter((r) => r.id !== requestId))
    alert("ইউজার ব্লক করা হয়েছে")
  }

  const handleStartChat = (friendId: string) => {
    const friend = friends.find((f) => f.id === friendId)
    if (friend) {
      setSelectedFriend(friend)
      setActiveChatId(friendId)

      const existingChat = chatList.find((c) => c.friendId === friendId)
      if (!existingChat) {
        const newChat: ChatItem = {
          id: Date.now().toString(),
          friendId: friend.id,
          friendName: friend.name,
          friendImage: friend.profileImage || profileGallery[Math.floor(Math.random() * profileGallery.length)],
          isOnline: friend.isOnline,
          lastMessage: "নতুন চ্যাট শুরু হয়েছে",
          lastMessageTime: new Date(),
          unreadCount: 0,
          lastMessageType: "text",
        }
        setChatList((prev) => [newChat, ...prev])
      }
    }
  }

  const handleChatSelect = (chatId: string) => {
    const chat = chatList.find((c) => c.id === chatId)
    if (chat) {
      const friend = friends.find((f) => f.id === chat.friendId)
      if (friend) {
        setSelectedFriend(friend)
        setActiveChatId(chatId)

        setChatList((prev) => prev.map((c) => (c.id === chatId ? { ...c, unreadCount: 0 } : c)))
      }
    }
  }

  const handleAudioCall = (friendId?: string) => {
    const friend = friendId ? friends.find((f) => f.id === friendId) : selectedFriend
    if (friend) {
      setCallFriend(friend)
      setIsInAudioCall(true)
      setCallDuration(0)
    }
  }

  const handleVideoCall = (friendId?: string) => {
    const friend = friendId ? friends.find((f) => f.id === friendId) : selectedFriend
    if (friend) {
      setCallFriend(friend)
      setIsInVideoCall(true)
      setCallDuration(0)
    }
  }

  const handleEndCall = () => {
    setIsInAudioCall(false)
    setIsInVideoCall(false)
    setCallFriend(null)
    setCallDuration(0)
  }

  const handleViewProfile = (friendId?: string) => {
    alert("প্রোফাইল দেখানো হবে")
  }

  const handleRemoveFriend = (friendId: string) => {
    const friend = friends.find((f) => f.id === friendId)
    if (confirm(`${friend?.name} কে বন্ধু তালিকা থেকে সরাতে চান?`)) {
      setFriends((prev) => prev.filter((f) => f.id !== friendId))
      setChatList((prev) => prev.filter((c) => c.friendId !== friendId))
      if (selectedFriend?.id === friendId) {
        setSelectedFriend(null)
        setActiveChatId(null)
      }
      alert("বন্ধু তালিকা থেকে সরানো হয়েছে")
    }
  }

  const handleBlockFriend = (friendId: string) => {
    const friend = friends.find((f) => f.id === friendId)
    if (confirm(`${friend?.name} কে ব্লক করতে চান?`)) {
      setFriends((prev) => prev.filter((f) => f.id !== friendId))
      setChatList((prev) => prev.filter((c) => c.friendId !== friendId))
      if (selectedFriend?.id === friendId) {
        setSelectedFriend(null)
        setActiveChatId(null)
      }
      alert("ইউজার ব্লক করা হয়েছে")
    }
  }

  const handleDeleteHistory = () => {
    alert("চ্যাট হিস্টরি মুছে ফেলা হয়েছে")
  }

  const handleBackToList = () => {
    setSelectedFriend(null)
    setActiveChatId(null)
    setSelectedGroup(null)
    setActiveGroupChatId(null)
  }

  const handleCreateGroup = (groupData: {
    name: string
    description: string
    members: string[]
  }) => {
    const newGroup: Group = {
      id: Date.now().toString(),
      name: groupData.name,
      description: groupData.description,
      createdBy: currentUser.email,
      createdAt: new Date().toISOString(),
      members: [
        {
          id: currentUser.email,
          name: currentUser.name,
          email: currentUser.email,
          profileImage: currentUser.profileImage,
          isOnline: true,
          isAdmin: true,
          joinedAt: new Date().toISOString(),
        },
        ...groupData.members.map((memberId) => {
          const friend = friends.find((f) => f.id === memberId)
          return {
            id: memberId,
            name: friend?.name || "",
            email: friend?.email || "",
            profileImage: friend?.profileImage || "",
            isOnline: friend?.isOnline || false,
            isAdmin: false,
            joinedAt: new Date().toISOString(),
          }
        }),
      ],
    }
    setGroups((prev) => [newGroup, ...prev])
    alert(`গ্রুপ "${groupData.name}" তৈরি করা হয়েছে!`)
  }

  const handleGroupSelect = (groupId: string) => {
    const group = groups.find((g) => g.id === groupId)
    if (group) {
      setSelectedGroup(group)
      setActiveGroupChatId(groupId)
      setSelectedFriend(null)
      setActiveChatId(null)
    }
  }

  const handleAddMembersToGroup = (groupId: string, memberIds: string[]) => {
    setGroups((prev) =>
      prev.map((group) => {
        if (group.id === groupId) {
          const newMembers = memberIds.map((memberId) => {
            const friend = friends.find((f) => f.id === memberId)
            return {
              id: memberId,
              name: friend?.name || "",
              email: friend?.email || "",
              profileImage: friend?.profileImage || "",
              isOnline: friend?.isOnline || false,
              isAdmin: false,
              joinedAt: new Date().toISOString(),
            }
          })
          return {
            ...group,
            members: [...group.members, ...newMembers],
          }
        }
        return group
      }),
    )

    if (selectedGroup?.id === groupId) {
      const updatedGroup = groups.find((g) => g.id === groupId)
      if (updatedGroup) setSelectedGroup(updatedGroup)
    }

    alert("নতুন সদস্য যোগ করা হয়েছে!")
  }

  const handleRemoveMemberFromGroup = (groupId: string, memberId: string) => {
    setGroups((prev) =>
      prev.map((group) => {
        if (group.id === groupId) {
          return {
            ...group,
            members: group.members.filter((m) => m.id !== memberId),
          }
        }
        return group
      }),
    )

    if (selectedGroup?.id === groupId) {
      const updatedGroup = groups.find((g) => g.id === groupId)
      if (updatedGroup) setSelectedGroup(updatedGroup)
    }

    alert("সদস্য সরানো হয়েছে!")
  }

  const handleLeaveGroup = (groupId: string) => {
    if (confirm("আপনি কি নিশ্চিত যে এই গ্রুপ ছেড়ে দিতে চান?")) {
      setGroups((prev) => prev.filter((g) => g.id !== groupId))
      if (selectedGroup?.id === groupId) {
        setSelectedGroup(null)
        setActiveGroupChatId(null)
      }
      alert("গ্রুপ ছেড়ে দেওয়া হয়েছে!")
    }
  }

  const handleDeleteGroup = (groupId: string) => {
    setGroups((prev) => prev.filter((g) => g.id !== groupId))
    if (selectedGroup?.id === groupId) {
      setSelectedGroup(null)
      setActiveGroupChatId(null)
    }
    setIsGroupInfoOpen(false)
    alert("গ্রুপ মুছে ফেলা হয়েছে!")
  }

  const handleUpdateGroup = (groupId: string, updates: { name?: string; description?: string }) => {
    setGroups((prev) => prev.map((group) => (group.id === groupId ? { ...group, ...updates } : group)))

    if (selectedGroup?.id === groupId) {
      setSelectedGroup((prev) => (prev ? { ...prev, ...updates } : null))
    }

    alert("গ্রুপ তথ্য আপডেট করা হয়েছে!")
  }

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault()
    if (authMode === "signup") {
      alert("ভেরিফিকেশন ইমেইল পাঠানো হয়েছে। আপনার Gmail চেক করুন।")
      setIsEmailVerified(true)
      setCurrentView("onboarding")
    } else {
      setCurrentUser({
        name: name || "ডেমো ইউজার",
        email: email,
        profileImage: profileGallery[0],
        gender: "পুরুষ",
        birthDate: "1990-01-01",
        country: "বাংলাদেশ",
        address: "ঢাকা",
        isOnline: true,
      })
      setCurrentView("dashboard")
    }
  }

  const handleProfileComplete = (profileData: any) => {
    setCurrentUser({
      name: name,
      email: email,
      profileImage: selectedProfileImage || profileGallery[0],
      gender: profileData.gender || "পুরুষ",
      birthDate: profileData.birthDate || "",
      country: profileData.country || "বাংলাদেশ",
      address: profileData.address || "",
      isOnline: true,
    })
    setCurrentView("dashboard")
  }

  const handleUpdateProfile = (updatedUser: UserProfile) => {
    setCurrentUser(updatedUser)
  }

  const handleStoryClick = (userId: string) => {
    const userStories = stories.filter((s) => s.userId === userId && s.expiresAt > Date.now())
    if (userStories.length > 0) {
      const storyIndex = stories.findIndex((s) => s.id === userStories[0].id)
      setCurrentStoryIndex(storyIndex)
      setIsStoryViewerOpen(true)
    }
  }

  const handleNextStory = () => {
    const activeStories = stories.filter((s) => s.expiresAt > Date.now())
    if (currentStoryIndex < activeStories.length - 1) {
      setCurrentStoryIndex(currentStoryIndex + 1)
    } else {
      setIsStoryViewerOpen(false)
    }
  }

  const handlePreviousStory = () => {
    if (currentStoryIndex > 0) {
      setCurrentStoryIndex(currentStoryIndex - 1)
    }
  }

  const handlePublishStory = (storyData: {
    type: "image" | "video" | "text"
    content: string
    backgroundColor?: string
  }) => {
    const newStory: Story = {
      id: Date.now().toString(),
      userId: "current-user",
      userName: currentUser.name,
      userAvatar: currentUser.profileImage,
      type: storyData.type,
      content: storyData.content,
      backgroundColor: storyData.backgroundColor,
      timestamp: Date.now(),
      expiresAt: Date.now() + 24 * 60 * 60 * 1000, // 24 hours
      views: [],
    }
    setStories((prev) => [newStory, ...prev])
    setIsStoryComposerOpen(false)
    alert("স্টোরি পাবলিশ করা হয়েছে!")
  }

  const getUniqueStoryUsers = () => {
    const activeStories = stories.filter((s) => s.expiresAt > Date.now())
    const userMap = new Map()

    const currentUserStories = activeStories.filter((s) => s.userId === "current-user")
    if (currentUserStories.length > 0) {
      userMap.set("current-user", {
        id: "current-user",
        name: currentUser.name,
        avatar: currentUser.profileImage,
        hasStory: true,
        isViewed: currentUserStories.every((s) => s.views.includes("current-user")),
      })
    }

    activeStories.forEach((story) => {
      if (story.userId !== "current-user" && !userMap.has(story.userId)) {
        userMap.set(story.userId, {
          id: story.userId,
          name: story.userName,
          avatar: story.userAvatar,
          hasStory: true,
          isViewed: story.views.includes("current-user"),
        })
      }
    })

    return Array.from(userMap.values())
  }

  if (isInAudioCall && callFriend) {
    return (
      <AudioCallInterface
        friend={{
          ...callFriend,
          profileImage: callFriend.profileImage || profileGallery[Math.floor(Math.random() * profileGallery.length)],
        }}
        onEndCall={handleEndCall}
        callDuration={callDuration}
      />
    )
  }

  if (isInVideoCall && callFriend) {
    return (
      <VideoCallInterface
        friend={{
          ...callFriend,
          profileImage: callFriend.profileImage || profileGallery[Math.floor(Math.random() * profileGallery.length)],
        }}
        onEndCall={handleEndCall}
        callDuration={callDuration}
      />
    )
  }

  if (currentView === "auth") {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4 mobile-safe-area">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold text-primary">ChatMax</CardTitle>
            <CardDescription>আধুনিক চ্যাট অ্যাপ্লিকেশন</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs value={authMode} onValueChange={setAuthMode}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="login">লগইন</TabsTrigger>
                <TabsTrigger value="signup">সাইন আপ</TabsTrigger>
              </TabsList>

              <TabsContent value="login">
                <form onSubmit={handleAuth} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">Gmail</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="আপনার Gmail ঠিকানা"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      className="mobile-touch-target"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password">পাসওয়ার্ড</Label>
                    <Input
                      id="password"
                      type="password"
                      placeholder="আপনার পাসওয়ার্ড"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      className="mobile-touch-target"
                    />
                  </div>
                  <Button type="submit" className="w-full mobile-touch-target">
                    লগইন করুন
                  </Button>
                </form>
              </TabsContent>

              <TabsContent value="signup">
                <form onSubmit={handleAuth} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">পূর্ণ নাম</Label>
                    <Input
                      id="name"
                      type="text"
                      placeholder="আপনার পূর্ণ নাম"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      required
                      className="mobile-touch-target"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="signup-email">Gmail (বাধ্যতামূলক)</Label>
                    <Input
                      id="signup-email"
                      type="email"
                      placeholder="আপনার Gmail ঠিকানা"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      className="mobile-touch-target"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="signup-password">পাসওয়ার্ড</Label>
                    <Input
                      id="signup-password"
                      type="password"
                      placeholder="একটি শক্তিশালী পাসওয়ার্ড"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      className="mobile-touch-target"
                    />
                  </div>
                  <Button type="submit" className="w-full mobile-touch-target">
                    সাইন আপ করুন
                  </Button>
                </form>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (currentView === "onboarding") {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4 mobile-safe-area">
        <Card className="w-full max-w-2xl">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold text-primary">প্রোফাইল সেটআপ</CardTitle>
            <CardDescription>আপনার প্রোফাইল তথ্য সম্পূর্ণ করুন</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="text-center">
              <h3 className="text-lg font-semibold mb-4">প্রোফাইল ছবি নির্বাচন করুন</h3>
              <div className="mb-4">
                <Avatar className="w-24 h-24 mx-auto">
                  <AvatarImage src={selectedProfileImage || profileGallery[0]} alt="Selected profile" />
                  <AvatarFallback>প্রোফাইল</AvatarFallback>
                </Avatar>
              </div>
              <div
                className={`grid ${isMobile ? "grid-cols-3" : "grid-cols-4"} gap-4 max-h-64 overflow-y-auto custom-scrollbar`}
              >
                {profileGallery.map((image, index) => (
                  <button
                    key={index}
                    className={`relative aspect-square rounded-lg overflow-hidden border-2 transition-all hover:scale-105 mobile-touch-target ${
                      selectedProfileImage === image
                        ? "border-primary ring-2 ring-primary/20"
                        : "border-border hover:border-primary/50"
                    }`}
                    onClick={() => setSelectedProfileImage(image)}
                  >
                    <img
                      src={image || "/placeholder.svg"}
                      alt={`Profile ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault()
                const formData = new FormData(e.currentTarget)
                handleProfileComplete({
                  gender: formData.get("gender"),
                  birthDate: formData.get("birthDate"),
                  country: formData.get("country"),
                  address: formData.get("address"),
                })
              }}
            >
              <div className={`grid ${isMobile ? "grid-cols-1" : "grid-cols-1 md:grid-cols-2"} gap-4`}>
                <div className="space-y-2">
                  <Label>লিঙ্গ</Label>
                  <Select name="gender" defaultValue="পুরুষ">
                    <SelectTrigger className="mobile-touch-target">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="পুরুষ">পুরুষ</SelectItem>
                      <SelectItem value="মহিলা">মহিলা</SelectItem>
                      <SelectItem value="অন্যান্য">অন্যান্য</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>জন্ম তারিখ</Label>
                  <Input name="birthDate" type="date" className="mobile-touch-target" />
                </div>
                <div className="space-y-2">
                  <Label>দেশ</Label>
                  <Input name="country" placeholder="বাংলাদেশ" defaultValue="বাংলাদেশ" className="mobile-touch-target" />
                </div>
                <div className="space-y-2">
                  <Label>ঠিকানা</Label>
                  <Input name="address" placeholder="আপনার ঠিকানা" className="mobile-touch-target" />
                </div>
              </div>

              <Button type="submit" className="w-full mt-6 mobile-touch-target">
                প্রোফাইল সম্পূর্ণ করুন
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className={`${isMobile ? "mobile-full-height" : "min-h-screen"} bg-background mobile-safe-area`}>
      {/* Header */}
      <header className="bg-card border-b border-border p-4">
        <div className={`flex items-center justify-between ${isMobile ? "" : "max-w-6xl mx-auto"}`}>
          <div className="flex items-center gap-3">
            {isMobile && !showSidebar && (
              <Button variant="ghost" size="icon" onClick={handleMobileBack} className="mobile-touch-target">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            )}
            <MessageCircle className="h-8 w-8 text-primary" />
            <h1 className={`${isMobile ? "text-xl" : "text-2xl"} font-bold text-primary`}>ChatMax</h1>
          </div>
          <div className="flex items-center gap-2">
            {!isMobile && (
              <>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setIsFriendSearchOpen(true)}
                  className="flex items-center gap-2"
                >
                  <Search className="w-4 h-4" />
                  বন্ধু খুঁজুন
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setIsGroupCreateOpen(true)}
                  className="flex items-center gap-2"
                >
                  <Users className="w-4 h-4" />
                  গ্রুপ তৈরি
                </Button>
              </>
            )}
            <Button variant="ghost" size="icon" className="mobile-touch-target">
              <Bell className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" className="mobile-touch-target">
              <Settings className="h-5 w-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="rounded-full p-0 w-10 h-10 mobile-touch-target"
              onClick={() => setIsProfilePopupOpen(true)}
            >
              <Avatar className="w-8 h-8">
                <AvatarImage src={currentUser.profileImage || "/placeholder.svg"} alt={currentUser.name} />
                <AvatarFallback>
                  <User className="w-4 h-4" />
                </AvatarFallback>
              </Avatar>
            </Button>
          </div>
        </div>
      </header>

      <div className={`flex ${isMobile ? "" : "max-w-6xl mx-auto"}`}>
        {/* Sidebar */}
        <div
          className={`${isMobile ? (showSidebar ? "w-full" : "hidden") : "w-80"} bg-card border-r border-border ${isMobile ? "h-[calc(100vh-80px)]" : "h-[calc(100vh-80px)]"}`}
        >
          <Tabs defaultValue="chats" className="h-full">
            <TabsList className={`grid w-full ${isMobile ? "grid-cols-3" : "grid-cols-5"} m-2`}>
              <TabsTrigger value="chats">চ্যাট</TabsTrigger>
              {!isMobile && <TabsTrigger value="groups">গ্রুপ</TabsTrigger>}
              <TabsTrigger value="friends">বন্ধু</TabsTrigger>
              <TabsTrigger value="stories">স্টোরি</TabsTrigger>
              <TabsTrigger value="requests">
                রিকোয়েস্ট
                {friendRequests.length > 0 && (
                  <span className="ml-1 bg-primary text-primary-foreground text-xs rounded-full px-2 py-0.5">
                    {friendRequests.length}
                  </span>
                )}
              </TabsTrigger>
            </TabsList>

            {isMobile && (
              <div className="p-4 border-b border-border">
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setIsFriendSearchOpen(true)}
                    className="flex-1 mobile-touch-target"
                  >
                    <Search className="w-4 h-4 mr-2" />
                    বন্ধু খুঁজুন
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setIsGroupCreateOpen(true)}
                    className="flex-1 mobile-touch-target"
                  >
                    <Users className="w-4 h-4 mr-2" />
                    গ্রুপ তৈরি
                  </Button>
                </div>
              </div>
            )}

            <TabsContent value="groups" className="p-4 space-y-2">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold">গ্রুপ চ্যাট ({groups.length})</h3>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setIsGroupCreateOpen(true)}
                  className="mobile-touch-target"
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              <div className="space-y-2 max-h-[calc(100vh-200px)] overflow-y-auto custom-scrollbar mobile-hide-scrollbar">
                {groups.length === 0 ? (
                  <div className="text-center text-muted-foreground py-8">কোনো গ্রুপ নেই</div>
                ) : (
                  groups.map((group) => (
                    <div
                      key={group.id}
                      className={`flex items-center p-3 rounded-lg cursor-pointer smooth-transition mobile-touch-target ${
                        activeGroupChatId === group.id ? "bg-primary/10" : "hover:bg-muted/50"
                      }`}
                      onClick={() => handleMobileGroupSelect(group.id)}
                    >
                      <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                        <Users className="w-6 h-6 text-primary" />
                      </div>
                      <div className="flex-1 ml-3">
                        <div className="flex items-center justify-between">
                          <span className="font-semibold">{group.name}</span>
                          <span className="text-sm text-muted-foreground">
                            {group.members.filter((m) => m.isOnline).length} অনলাইন
                          </span>
                        </div>
                        <p className="text-sm text-muted-foreground">{group.members.length} জন সদস্য</p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </TabsContent>

            <TabsContent value="chats" className="p-4 space-y-2">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold">সাম্প্রতিক চ্যাট ({chatList.length})</h3>
                <Button size="sm" variant="ghost" className="mobile-touch-target">
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              <div className="space-y-2 max-h-[calc(100vh-200px)] overflow-y-auto custom-scrollbar mobile-hide-scrollbar">
                {chatList.length === 0 ? (
                  <div className="text-center text-muted-foreground py-8">কোনো চ্যাট নেই</div>
                ) : (
                  chatList.map((chat) => (
                    <div
                      key={chat.id}
                      className={`flex items-center p-3 rounded-lg cursor-pointer smooth-transition mobile-touch-target ${
                        activeChatId === chat.id ? "bg-primary/10" : "hover:bg-muted/50"
                      }`}
                      onClick={() => handleMobileChatSelect(chat.id)}
                    >
                      <Avatar className="w-10 h-10">
                        <AvatarImage
                          src={chat.friendImage || profileGallery[Math.floor(Math.random() * profileGallery.length)]}
                          alt={chat.friendName}
                        />
                        <AvatarFallback>{chat.friendName.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 ml-3">
                        <div className="flex items-center justify-between">
                          <span className="font-semibold">{chat.friendName}</span>
                          <span className="text-sm text-muted-foreground">
                            {chat.lastMessageTime.toLocaleTimeString()}
                          </span>
                        </div>
                        <p className="text-sm text-muted-foreground truncate">{chat.lastMessage}</p>
                      </div>
                      {chat.unreadCount > 0 && (
                        <span className="bg-primary text-primary-foreground text-xs rounded-full px-2 py-0.5">
                          {chat.unreadCount}
                        </span>
                      )}
                    </div>
                  ))
                )}
              </div>
            </TabsContent>

            <TabsContent value="friends" className="p-4 space-y-2">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold">বন্ধুদের তালিকা ({friends.length})</h3>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setIsFriendSearchOpen(true)}
                  className="mobile-touch-target"
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              <div className="space-y-2 max-h-[calc(100vh-200px)] overflow-y-auto custom-scrollbar mobile-hide-scrollbar">
                {friends.length === 0 ? (
                  <div className="text-center text-muted-foreground py-8">কোনো বন্ধু নেই</div>
                ) : (
                  friends.map((friend) => (
                    <FriendItem
                      key={friend.id}
                      friend={{
                        ...friend,
                        profileImage:
                          friend.profileImage || profileGallery[Math.floor(Math.random() * profileGallery.length)],
                      }}
                      onStartChat={handleMobileStartChat}
                      onAudioCall={handleAudioCall}
                      onVideoCall={handleVideoCall}
                      onViewProfile={handleViewProfile}
                      onRemoveFriend={handleRemoveFriend}
                      onBlockFriend={handleBlockFriend}
                    />
                  ))
                )}
              </div>
            </TabsContent>

            <TabsContent value="stories" className="p-4 space-y-2">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold">স্টোরি</h3>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setIsStoryComposerOpen(true)}
                  className="mobile-touch-target"
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              <div className="space-y-4">
                {getUniqueStoryUsers().length === 0 ? (
                  <div className="text-center text-muted-foreground py-8">কোনো স্টোরি নেই</div>
                ) : (
                  <div className={`grid ${isMobile ? "grid-cols-3" : "grid-cols-4"} gap-4`}>
                    {getUniqueStoryUsers().map((user) => (
                      <StoryRing
                        key={user.id}
                        user={user}
                        hasStory={user.hasStory}
                        isViewed={user.isViewed}
                        onClick={() => handleStoryClick(user.id)}
                      />
                    ))}
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="requests" className="p-4 space-y-2">
              <h3 className="font-semibold mb-4">বন্ধুত্বের অনুরোধ ({friendRequests.length})</h3>
              <div className="space-y-2 max-h-[calc(100vh-200px)] overflow-y-auto custom-scrollbar mobile-hide-scrollbar">
                {friendRequests.length === 0 ? (
                  <div className="text-center text-muted-foreground py-8">কোনো অনুরোধ নেই</div>
                ) : (
                  friendRequests.map((request) => (
                    <FriendRequestItem
                      key={request.id}
                      request={{
                        ...request,
                        profileImage:
                          request.profileImage || profileGallery[Math.floor(Math.random() * profileGallery.length)],
                      }}
                      onAccept={handleAcceptRequest}
                      onReject={handleRejectRequest}
                      onBlock={handleBlockRequest}
                    />
                  ))
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Main Content */}
        <div className={`${isMobile ? (showSidebar ? "hidden" : "w-full") : "flex-1"} bg-background`}>
          {selectedGroup ? (
            <GroupChatInterface
              group={selectedGroup}
              currentUserId={currentUser.email}
              onBack={() => {
                handleBackToList()
                if (isMobile) setShowSidebar(true)
              }}
              onGroupInfo={() => setIsGroupInfoOpen(true)}
              onDeleteHistory={() => alert("গ্রুপ চ্যাট হিস্টরি মুছে ফেলা হয়েছে")}
              profileGallery={profileGallery}
            />
          ) : selectedFriend ? (
            <ChatInterface
              friend={{
                ...selectedFriend,
                profileImage:
                  selectedFriend.profileImage || profileGallery[Math.floor(Math.random() * profileGallery.length)],
              }}
              currentUser={currentUser}
              onBack={() => {
                handleBackToList()
                if (isMobile) setShowSidebar(true)
              }}
              onAudioCall={() => handleAudioCall()}
              onVideoCall={() => handleVideoCall()}
              onViewProfile={() => handleViewProfile()}
              onDeleteHistory={handleDeleteHistory}
              onBlockUser={() => handleBlockFriend(selectedFriend.id)}
            />
          ) : (
            <div
              className={`${isMobile ? "h-[calc(100vh-80px)]" : "h-[calc(100vh-80px)]"} flex items-center justify-center`}
            >
              <div className="text-center space-y-4 p-8">
                <MessageCircle className="h-16 w-16 text-muted-foreground mx-auto" />
                <h2 className={`${isMobile ? "text-lg" : "text-xl"} font-semibold text-muted-foreground`}>
                  ChatMax এ স্বাগতম
                </h2>
                <p className="text-muted-foreground">একটি চ্যাট বা গ্রুপ নির্বাচন করুন</p>
                {isMobile && (
                  <Button onClick={() => setShowSidebar(true)} className="mobile-touch-target">
                    চ্যাট তালিকা দেখুন
                  </Button>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      <UserProfilePopup
        isOpen={isProfilePopupOpen}
        onClose={() => setIsProfilePopupOpen(false)}
        user={currentUser}
        onUpdateProfile={handleUpdateProfile}
        isOwnProfile={true}
        profileGallery={profileGallery}
      />

      <FriendSearchPopup
        isOpen={isFriendSearchOpen}
        onClose={() => setIsFriendSearchOpen(false)}
        onSendRequest={handleSendFriendRequest}
        profileGallery={profileGallery}
      />

      {isStoryViewerOpen && (
        <StoryViewer
          stories={stories.filter((s) => s.expiresAt > Date.now())}
          currentStoryIndex={currentStoryIndex}
          onClose={() => setIsStoryViewerOpen(false)}
          onNext={handleNextStory}
          onPrevious={handlePreviousStory}
          currentUser="current-user"
        />
      )}

      {isStoryComposerOpen && (
        <StoryComposer onClose={() => setIsStoryComposerOpen(false)} onPublish={handlePublishStory} />
      )}

      {isGroupCreateOpen && (
        <GroupCreatePopup
          isOpen={isGroupCreateOpen}
          onClose={() => setIsGroupCreateOpen(false)}
          friends={friends}
          onCreateGroup={handleCreateGroup}
          profileGallery={profileGallery}
        />
      )}

      {selectedGroup && (
        <GroupInfoPopup
          isOpen={isGroupInfoOpen}
          onClose={() => setIsGroupInfoOpen(false)}
          group={selectedGroup}
          currentUserId={currentUser.email}
          friends={friends}
          onAddMembers={handleAddMembersToGroup}
          onRemoveMember={handleRemoveMemberFromGroup}
          onLeaveGroup={handleLeaveGroup}
          onDeleteGroup={handleDeleteGroup}
          onUpdateGroup={handleUpdateGroup}
          profileGallery={profileGallery}
        />
      )}
    </div>
  )
}
